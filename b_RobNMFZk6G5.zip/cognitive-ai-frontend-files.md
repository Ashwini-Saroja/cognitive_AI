# Cognitive AI - Neural Intelligence Suite

All frontend files for the futuristic AI dashboard application.

---

## File Structure

```
app/
├── globals.css
├── layout.tsx
├── page.tsx                    # Login/Onboarding
└── dashboard/
    ├── layout.tsx
    ├── page.tsx                # Command Center
    ├── transcript/
    │   └── page.tsx            # Live Transcript & Summary
    ├── repository/
    │   └── page.tsx            # Cognitive Repository
    └── settings/
        └── page.tsx            # Configuration Console

components/
├── neural-background.tsx
├── glass-card.tsx
├── glow-button.tsx
├── stat-card.tsx
├── dashboard-sidebar.tsx
└── audio-waveform.tsx
```

---

## app/globals.css

```css
@import 'tailwindcss';
@import 'tw-animate-css';

@custom-variant dark (&:is(.dark *));

:root {
  /* Cyberpunk Dark Theme */
  --background: #050816;
  --foreground: #e0e0ff;
  --card: rgba(255, 255, 255, 0.04);
  --card-foreground: #e0e0ff;
  --popover: rgba(10, 15, 35, 0.95);
  --popover-foreground: #e0e0ff;
  --primary: #00D9FF;
  --primary-foreground: #050816;
  --secondary: rgba(122, 95, 255, 0.15);
  --secondary-foreground: #7A5FFF;
  --muted: rgba(255, 255, 255, 0.06);
  --muted-foreground: #8888aa;
  --accent: #7A5FFF;
  --accent-foreground: #ffffff;
  --destructive: #ff4466;
  --destructive-foreground: #ffffff;
  --border: rgba(0, 217, 255, 0.15);
  --input: rgba(255, 255, 255, 0.08);
  --ring: #00D9FF;
  --chart-1: #00D9FF;
  --chart-2: #7A5FFF;
  --chart-3: #00ff88;
  --chart-4: #ff6b35;
  --chart-5: #ff4466;
  --radius: 0.75rem;
  
  /* Custom tokens */
  --neon-blue: #00D9FF;
  --neon-purple: #7A5FFF;
  --neon-green: #00ff88;
  --glass: rgba(255, 255, 255, 0.06);
  --glass-border: rgba(0, 217, 255, 0.2);
  --glow-blue: 0 0 20px rgba(0, 217, 255, 0.3);
  --glow-purple: 0 0 20px rgba(122, 95, 255, 0.3);
  
  /* Sidebar */
  --sidebar: rgba(10, 15, 35, 0.8);
  --sidebar-foreground: #e0e0ff;
  --sidebar-primary: #00D9FF;
  --sidebar-primary-foreground: #050816;
  --sidebar-accent: rgba(122, 95, 255, 0.15);
  --sidebar-accent-foreground: #7A5FFF;
  --sidebar-border: rgba(0, 217, 255, 0.1);
  --sidebar-ring: #00D9FF;
}

@theme inline {
  --font-sans: 'Inter', 'Geist', system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', 'Geist Mono', monospace;
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-card: var(--card);
  --color-card-foreground: var(--card-foreground);
  --color-popover: var(--popover);
  --color-popover-foreground: var(--popover-foreground);
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-secondary: var(--secondary);
  --color-secondary-foreground: var(--secondary-foreground);
  --color-muted: var(--muted);
  --color-muted-foreground: var(--muted-foreground);
  --color-accent: var(--accent);
  --color-accent-foreground: var(--accent-foreground);
  --color-destructive: var(--destructive);
  --color-destructive-foreground: var(--destructive-foreground);
  --color-border: var(--border);
  --color-input: var(--input);
  --color-ring: var(--ring);
  --color-chart-1: var(--chart-1);
  --color-chart-2: var(--chart-2);
  --color-chart-3: var(--chart-3);
  --color-chart-4: var(--chart-4);
  --color-chart-5: var(--chart-5);
  --radius-sm: calc(var(--radius) - 4px);
  --radius-md: calc(var(--radius) - 2px);
  --radius-lg: var(--radius);
  --radius-xl: calc(var(--radius) + 4px);
  --color-sidebar: var(--sidebar);
  --color-sidebar-foreground: var(--sidebar-foreground);
  --color-sidebar-primary: var(--sidebar-primary);
  --color-sidebar-primary-foreground: var(--sidebar-primary-foreground);
  --color-sidebar-accent: var(--sidebar-accent);
  --color-sidebar-accent-foreground: var(--sidebar-accent-foreground);
  --color-sidebar-border: var(--sidebar-border);
  --color-sidebar-ring: var(--sidebar-ring);
  
  /* Custom color tokens */
  --color-neon-blue: var(--neon-blue);
  --color-neon-purple: var(--neon-purple);
  --color-neon-green: var(--neon-green);
  --color-glass: var(--glass);
  --color-glass-border: var(--glass-border);
}

@layer base {
  * {
    @apply border-border outline-ring/50;
  }
  body {
    @apply bg-background text-foreground;
  }
}

/* Custom animations */
@keyframes pulse-glow {
  0%, 100% {
    box-shadow: 0 0 20px rgba(0, 217, 255, 0.3);
  }
  50% {
    box-shadow: 0 0 40px rgba(0, 217, 255, 0.6);
  }
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}

@keyframes wave {
  0% {
    transform: scaleY(1);
  }
  50% {
    transform: scaleY(0.5);
  }
  100% {
    transform: scaleY(1);
  }
}

.animate-pulse-glow {
  animation: pulse-glow 2s ease-in-out infinite;
}

.animate-float {
  animation: float 3s ease-in-out infinite;
}

.animate-shimmer {
  background: linear-gradient(90deg, transparent, rgba(0, 217, 255, 0.1), transparent);
  background-size: 200% 100%;
  animation: shimmer 2s infinite;
}

.glass-panel {
  background: rgba(255, 255, 255, 0.04);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(0, 217, 255, 0.15);
}

.glass-panel-purple {
  background: rgba(122, 95, 255, 0.08);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(122, 95, 255, 0.2);
}

.glow-border {
  box-shadow: 0 0 20px rgba(0, 217, 255, 0.2), inset 0 0 20px rgba(0, 217, 255, 0.05);
}

.glow-border-purple {
  box-shadow: 0 0 20px rgba(122, 95, 255, 0.2), inset 0 0 20px rgba(122, 95, 255, 0.05);
}

.text-glow {
  text-shadow: 0 0 20px rgba(0, 217, 255, 0.5);
}

.text-glow-purple {
  text-shadow: 0 0 20px rgba(122, 95, 255, 0.5);
}

/* Scrollbar styling */
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.02);
}

::-webkit-scrollbar-thumb {
  background: rgba(0, 217, 255, 0.3);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 217, 255, 0.5);
}
```

---

## app/layout.tsx

```tsx
import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
})

const jetbrainsMono = JetBrains_Mono({ 
  subsets: ['latin'],
  variable: '--font-jetbrains-mono',
})

export const metadata: Metadata = {
  title: 'Cognitive AI — Neural Intelligence Suite',
  description: 'The Future of Neural Intelligence. An end-to-end Executive Intelligence suite powered by quantum-enhanced AI systems.',
  generator: 'v0.app',
  keywords: ['AI', 'Neural Intelligence', 'Enterprise', 'Machine Learning', 'Executive Suite'],
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#050816',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrainsMono.variable} bg-[#050816]`}>
      <body className="font-sans antialiased bg-[#050816] text-[#e0e0ff] min-h-screen">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
```

---

## app/page.tsx (Login/Onboarding)

```tsx
"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Brain,
  Fingerprint,
  Zap,
  Shield,
  Cpu,
  Mail,
  Lock,
  ArrowRight,
  Sparkles,
} from "lucide-react"
import { NeuralBackground } from "@/components/neural-background"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"
import { StatCard } from "@/components/stat-card"
import Link from "next/link"

export default function OnboardingPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#050816]">
      <NeuralBackground />

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#050816]/50 to-[#050816] pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-[radial-gradient(ellipse_at_center,rgba(122,95,255,0.15)_0%,transparent_70%)] pointer-events-none" />

      <div className="relative z-10 container mx-auto px-4 py-8 min-h-screen flex flex-col">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-between mb-12"
        >
          <div className="flex items-center gap-3">
            <div className="relative">
              <Brain className="w-10 h-10 text-[#00D9FF]" />
              <div className="absolute inset-0 blur-lg bg-[#00D9FF]/40" />
            </div>
            <span className="text-2xl font-bold tracking-tight">
              <span className="text-[#00D9FF] text-glow">COGNITIVE</span>
              <span className="text-[#e0e0ff]"> AI</span>
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-[#8888aa] hover:text-[#00D9FF] transition-colors text-sm">
              Enterprise
            </a>
            <a href="#" className="text-[#8888aa] hover:text-[#00D9FF] transition-colors text-sm">
              Documentation
            </a>
            <a href="#" className="text-[#8888aa] hover:text-[#00D9FF] transition-colors text-sm">
              Security
            </a>
          </nav>
        </motion.header>

        {/* Main Content */}
        <div className="flex-1 flex items-center justify-center">
          <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Hero content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[rgba(122,95,255,0.15)] border border-[rgba(122,95,255,0.3)]"
                >
                  <Sparkles className="w-4 h-4 text-[#7A5FFF]" />
                  <span className="text-sm text-[#7A5FFF]">Neural Intelligence Suite v4.0</span>
                </motion.div>

                <h1 className="text-5xl lg:text-6xl font-bold leading-tight text-balance">
                  <span className="text-[#e0e0ff]">The Future of </span>
                  <span className="text-[#00D9FF] text-glow">Neural Intelligence</span>
                </h1>

                <p className="text-xl text-[#8888aa] leading-relaxed max-w-lg">
                  An end-to-end Executive Intelligence suite powered by quantum-enhanced AI systems and neural processing networks.
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4">
                <StatCard
                  label="Latency"
                  value="12ms"
                  icon={Zap}
                  delay={0.4}
                />
                <StatCard
                  label="Encryption"
                  value="Quantum"
                  icon={Shield}
                  delay={0.5}
                />
                <StatCard
                  label="Efficiency"
                  value="99.2%"
                  icon={Cpu}
                  delay={0.6}
                />
              </div>

              {/* Features */}
              <div className="flex flex-wrap gap-3">
                {["Neural Processing", "Real-time Analytics", "Enterprise Security", "Multi-modal AI"].map(
                  (feature, index) => (
                    <motion.span
                      key={feature}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: 0.7 + index * 0.1 }}
                      className="px-3 py-1.5 text-sm text-[#8888aa] bg-[rgba(255,255,255,0.04)] rounded-lg border border-[rgba(255,255,255,0.08)]"
                    >
                      {feature}
                    </motion.span>
                  )
                )}
              </div>
            </motion.div>

            {/* Right side - Login card */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
            >
              <GlassCard className="p-8" hover={false}>
                <div className="space-y-6">
                  <div className="text-center space-y-2">
                    <h2 className="text-2xl font-bold text-[#e0e0ff]">
                      Access Neural Console
                    </h2>
                    <p className="text-[#8888aa] text-sm">
                      Secure enterprise authentication required
                    </p>
                  </div>

                  <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                    <div className="space-y-2">
                      <label className="text-sm text-[#8888aa]">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8888aa]" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="executive@enterprise.com"
                          className="w-full pl-11 pr-4 py-3 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] placeholder:text-[#555566] focus:outline-none focus:border-[#00D9FF] focus:shadow-[0_0_20px_rgba(0,217,255,0.2)] transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-[#8888aa]">Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8888aa]" />
                        <input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Enter secure passkey"
                          className="w-full pl-11 pr-4 py-3 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] placeholder:text-[#555566] focus:outline-none focus:border-[#00D9FF] focus:shadow-[0_0_20px_rgba(0,217,255,0.2)] transition-all"
                        />
                      </div>
                    </div>

                    <Link href="/dashboard">
                      <GlowButton className="w-full" size="lg">
                        <span>Initialize Session</span>
                        <ArrowRight className="w-5 h-5" />
                      </GlowButton>
                    </Link>
                  </form>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-[rgba(255,255,255,0.1)]" />
                    </div>
                    <div className="relative flex justify-center text-xs">
                      <span className="px-4 bg-[#0a0f23] text-[#555566]">
                        or continue with
                      </span>
                    </div>
                  </div>

                  <GlowButton variant="secondary" className="w-full" size="md">
                    <Fingerprint className="w-5 h-5" />
                    <span>Biometric Authentication</span>
                  </GlowButton>

                  <p className="text-center text-sm text-[#555566]">
                    {"Don't have access?"}{" "}
                    <a href="#" className="text-[#00D9FF] hover:underline">
                      Request Enterprise Access
                    </a>
                  </p>
                </div>
              </GlassCard>

              {/* Security badge */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="mt-4 flex items-center justify-center gap-2 text-xs text-[#555566]"
              >
                <Shield className="w-4 h-4" />
                <span>Protected by Quantum Encryption Protocol</span>
              </motion.div>
            </motion.div>
          </div>
        </div>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-center text-xs text-[#555566] mt-8"
        >
          <p>Cognitive AI Neural Intelligence Suite - Enterprise Edition</p>
          <p className="mt-1">Quantum-secured • SOC 2 Certified • GDPR Compliant</p>
        </motion.footer>
      </div>
    </main>
  )
}
```

---

## app/dashboard/layout.tsx

```tsx
"use client"

import { DashboardSidebar } from "@/components/dashboard-sidebar"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-[#050816]">
      <DashboardSidebar />
      <main className="ml-64 min-h-screen transition-all duration-300">
        {children}
      </main>
    </div>
  )
}
```

---

## app/dashboard/page.tsx (Command Center)

```tsx
"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Play,
  Pause,
  Mic,
  Activity,
  Zap,
  Shield,
  Clock,
  TrendingUp,
  MessageSquare,
  BarChart3,
  Users,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"
import { StatCard } from "@/components/stat-card"
import { AudioWaveform } from "@/components/audio-waveform"

const recentConversations = [
  {
    id: 1,
    title: "Q4 Strategy Meeting",
    participants: 4,
    duration: "45:23",
    sentiment: "positive",
    time: "2 hours ago",
  },
  {
    id: 2,
    title: "Product Roadmap Review",
    participants: 6,
    duration: "1:12:45",
    sentiment: "neutral",
    time: "5 hours ago",
  },
  {
    id: 3,
    title: "Client Onboarding Call",
    participants: 3,
    duration: "32:10",
    sentiment: "positive",
    time: "Yesterday",
  },
]

const activityTimeline = [
  { time: "14:32", event: "Session initialized", type: "start" },
  { time: "14:33", event: "Neural processing active", type: "process" },
  { time: "14:35", event: "Summary generated", type: "complete" },
  { time: "14:36", event: "Action items extracted", type: "complete" },
  { time: "14:40", event: "Session archived", type: "end" },
]

export default function CommandCenterPage() {
  const [isSessionActive, setIsSessionActive] = useState(false)

  return (
    <div className="p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
          Live Command Center
        </h1>
        <p className="text-[#8888aa]">
          Real-time AI session control and monitoring
        </p>
      </motion.div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Processing Latency"
          value="12ms"
          icon={Zap}
          trend="down"
          trendValue="3ms faster"
          delay={0.1}
        />
        <StatCard
          label="Token Efficiency"
          value="99.2%"
          icon={TrendingUp}
          trend="up"
          trendValue="+0.8%"
          delay={0.2}
        />
        <StatCard
          label="SSL Status"
          value="Active"
          icon={Shield}
          trend="neutral"
          trendValue="256-bit"
          delay={0.3}
        />
        <StatCard
          label="Sessions Today"
          value="24"
          icon={Activity}
          trend="up"
          trendValue="+12"
          delay={0.4}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* AI Session Panel - Takes 2 columns */}
        <div className="col-span-2 space-y-6">
          {/* Session Control */}
          <GlassCard className="p-6" delay={0.2}>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-semibold text-[#e0e0ff] mb-1">
                  Neural Session
                </h2>
                <p className="text-sm text-[#8888aa]">
                  {isSessionActive
                    ? "Session active - Processing audio stream"
                    : "Ready to initialize new session"}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div
                  className={`w-3 h-3 rounded-full ${
                    isSessionActive
                      ? "bg-[#00ff88] animate-pulse"
                      : "bg-[#555566]"
                  }`}
                />
                <span
                  className={`text-sm ${
                    isSessionActive ? "text-[#00ff88]" : "text-[#8888aa]"
                  }`}
                >
                  {isSessionActive ? "LIVE" : "STANDBY"}
                </span>
              </div>
            </div>

            {/* Waveform Visualizer */}
            <div className="mb-6 p-4 rounded-xl bg-[rgba(0,0,0,0.3)] border border-[rgba(0,217,255,0.1)]">
              <AudioWaveform isActive={isSessionActive} />
            </div>

            {/* Session Controls */}
            <div className="flex items-center justify-center gap-4">
              <GlowButton
                variant="ghost"
                size="lg"
                className="w-14 h-14 rounded-full p-0"
              >
                <Mic className="w-6 h-6" />
              </GlowButton>

              <GlowButton
                variant={isSessionActive ? "secondary" : "primary"}
                size="lg"
                className="px-12"
                onClick={() => setIsSessionActive(!isSessionActive)}
              >
                {isSessionActive ? (
                  <>
                    <Pause className="w-5 h-5" />
                    <span>End Session</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5" />
                    <span>Start Session</span>
                  </>
                )}
              </GlowButton>

              <GlowButton
                variant="ghost"
                size="lg"
                className="w-14 h-14 rounded-full p-0"
              >
                <BarChart3 className="w-6 h-6" />
              </GlowButton>
            </div>
          </GlassCard>

          {/* Recent Conversations */}
          <GlassCard className="p-6" delay={0.3}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Recent Sessions
              </h2>
              <a
                href="/dashboard/repository"
                className="text-sm text-[#00D9FF] hover:underline"
              >
                View All
              </a>
            </div>

            <div className="space-y-3">
              {recentConversations.map((conv, index) => (
                <motion.div
                  key={conv.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  whileHover={{ x: 5 }}
                  className="p-4 rounded-xl bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.05)] hover:border-[rgba(0,217,255,0.2)] transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-[#e0e0ff] mb-1">
                        {conv.title}
                      </h3>
                      <div className="flex items-center gap-4 text-xs text-[#8888aa]">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {conv.participants}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {conv.duration}
                        </span>
                        <span>{conv.time}</span>
                      </div>
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs ${
                        conv.sentiment === "positive"
                          ? "bg-[rgba(0,255,136,0.15)] text-[#00ff88]"
                          : "bg-[rgba(255,255,255,0.1)] text-[#8888aa]"
                      }`}
                    >
                      {conv.sentiment}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Right Column - Activity & Metrics */}
        <div className="space-y-6">
          {/* Live Metrics */}
          <GlassCard className="p-6" glow="purple" delay={0.25}>
            <h2 className="text-lg font-semibold text-[#e0e0ff] mb-4">
              Live Metrics
            </h2>

            <div className="space-y-4">
              {/* Processing Power */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#8888aa]">Neural Processing</span>
                  <span className="text-[#00D9FF]">87%</span>
                </div>
                <div className="h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "87%" }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#00D9FF] to-[#7A5FFF]"
                  />
                </div>
              </div>

              {/* Memory Usage */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#8888aa]">Memory Allocation</span>
                  <span className="text-[#7A5FFF]">62%</span>
                </div>
                <div className="h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "62%" }}
                    transition={{ duration: 1, delay: 0.6 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#7A5FFF] to-[#00D9FF]"
                  />
                </div>
              </div>

              {/* Token Usage */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#8888aa]">Token Usage</span>
                  <span className="text-[#00ff88]">45%</span>
                </div>
                <div className="h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "45%" }}
                    transition={{ duration: 1, delay: 0.7 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#00ff88] to-[#00D9FF]"
                  />
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Activity Timeline */}
          <GlassCard className="p-6" delay={0.35}>
            <h2 className="text-lg font-semibold text-[#e0e0ff] mb-4">
              Activity Timeline
            </h2>

            <div className="space-y-3">
              {activityTimeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        item.type === "start"
                          ? "bg-[#00D9FF]"
                          : item.type === "complete"
                          ? "bg-[#00ff88]"
                          : item.type === "process"
                          ? "bg-[#7A5FFF]"
                          : "bg-[#8888aa]"
                      }`}
                    />
                    {index < activityTimeline.length - 1 && (
                      <div className="w-px h-6 bg-[rgba(255,255,255,0.1)]" />
                    )}
                  </div>
                  <div className="flex-1 -mt-0.5">
                    <p className="text-sm text-[#e0e0ff]">{item.event}</p>
                    <p className="text-xs text-[#555566]">{item.time}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Quick Actions */}
          <GlassCard className="p-6" delay={0.45}>
            <h2 className="text-lg font-semibold text-[#e0e0ff] mb-4">
              Quick Actions
            </h2>

            <div className="grid grid-cols-2 gap-3">
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <MessageSquare className="w-5 h-5 mb-1" />
                <span className="text-xs">New Chat</span>
              </GlowButton>
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <Mic className="w-5 h-5 mb-1" />
                <span className="text-xs">Voice Note</span>
              </GlowButton>
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <BarChart3 className="w-5 h-5 mb-1" />
                <span className="text-xs">Analytics</span>
              </GlowButton>
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <Users className="w-5 h-5 mb-1" />
                <span className="text-xs">Team</span>
              </GlowButton>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}
```

---

## app/dashboard/transcript/page.tsx (Live Transcript & Summary)

```tsx
"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Mic,
  MicOff,
  Download,
  Share2,
  CheckSquare,
  Target,
  Heart,
  Building2,
  User,
  Clock,
  TrendingUp,
  Sparkles,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"

const speakers = [
  { id: "sarah", name: "Sarah Chen", role: "CEO", color: "#00D9FF" },
  { id: "marcus", name: "Marcus Johnson", role: "CTO", color: "#7A5FFF" },
  { id: "elena", name: "Elena Rodriguez", role: "Product", color: "#00ff88" },
]

const initialTranscript = [
  {
    id: 1,
    speaker: "sarah",
    text: "Let's discuss our Q4 roadmap priorities. I believe we should focus on the enterprise features our clients have been requesting.",
    timestamp: "00:00:12",
    sentiment: "positive",
  },
  {
    id: 2,
    speaker: "marcus",
    text: "Agreed. The technical infrastructure is ready to support the new authentication system. We can have the SSO integration completed within three weeks.",
    timestamp: "00:00:34",
    sentiment: "positive",
  },
  {
    id: 3,
    speaker: "elena",
    text: "From a product perspective, I think we should also prioritize the analytics dashboard. User feedback has been overwhelmingly positive about the beta version.",
    timestamp: "00:01:02",
    sentiment: "positive",
  },
  {
    id: 4,
    speaker: "sarah",
    text: "Excellent points. Marcus, what resources would you need to accelerate the SSO timeline?",
    timestamp: "00:01:28",
    sentiment: "neutral",
  },
  {
    id: 5,
    speaker: "marcus",
    text: "Two additional senior engineers and access to the Azure AD sandbox environment. I can have a detailed proposal by end of day.",
    timestamp: "00:01:45",
    sentiment: "neutral",
  },
]

const aiSummary = {
  keyObjectives: [
    "Complete SSO integration within 3 weeks",
    "Prioritize enterprise authentication features",
    "Launch analytics dashboard based on beta feedback",
    "Allocate additional engineering resources",
  ],
  actionItems: [
    { task: "Prepare SSO resource proposal", assignee: "Marcus Johnson", due: "Today EOD" },
    { task: "Schedule Azure AD sandbox access", assignee: "IT Team", due: "Tomorrow" },
    { task: "Share beta analytics feedback report", assignee: "Elena Rodriguez", due: "This week" },
    { task: "Review Q4 budget for new hires", assignee: "Sarah Chen", due: "Friday" },
  ],
  entities: [
    { type: "Organization", value: "Azure AD" },
    { type: "Feature", value: "SSO Integration" },
    { type: "Feature", value: "Analytics Dashboard" },
    { type: "Timeline", value: "Q4 Roadmap" },
  ],
  sentimentAnalysis: {
    overall: "Positive",
    score: 78,
    breakdown: { positive: 65, neutral: 30, negative: 5 },
  },
}

export default function TranscriptPage() {
  const [isRecording, setIsRecording] = useState(false)
  const [transcript, setTranscript] = useState(initialTranscript)
  const [typingIndex, setTypingIndex] = useState<number | null>(null)

  // Simulate live transcription
  useEffect(() => {
    if (!isRecording) return

    const newMessages = [
      {
        id: transcript.length + 1,
        speaker: "elena",
        text: "I can also provide user research data to support the SSO prioritization decision.",
        timestamp: "00:02:15",
        sentiment: "positive",
      },
      {
        id: transcript.length + 2,
        speaker: "sarah",
        text: "Perfect. Let's reconvene Thursday with all proposals on the table.",
        timestamp: "00:02:38",
        sentiment: "positive",
      },
    ]

    const timeouts: NodeJS.Timeout[] = []
    
    newMessages.forEach((msg, index) => {
      const timeout = setTimeout(() => {
        setTypingIndex(msg.id)
        setTimeout(() => {
          setTranscript((prev) => [...prev, msg])
          setTypingIndex(null)
        }, 1500)
      }, (index + 1) * 3000)
      timeouts.push(timeout)
    })

    return () => timeouts.forEach(clearTimeout)
  }, [isRecording, transcript.length])

  const getSpeaker = (id: string) => speakers.find((s) => s.id === id) || speakers[0]

  return (
    <div className="p-8 h-[calc(100vh-2rem)]">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between mb-6"
      >
        <div>
          <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
            Live Transcript & Summary
          </h1>
          <p className="text-[#8888aa]">
            AI-powered meeting intelligence with real-time analysis
          </p>
        </div>
        <div className="flex items-center gap-3">
          <GlowButton
            variant={isRecording ? "secondary" : "primary"}
            onClick={() => setIsRecording(!isRecording)}
          >
            {isRecording ? (
              <>
                <MicOff className="w-5 h-5" />
                <span>Stop Recording</span>
              </>
            ) : (
              <>
                <Mic className="w-5 h-5" />
                <span>Start Recording</span>
              </>
            )}
          </GlowButton>
          <GlowButton variant="ghost">
            <Download className="w-5 h-5" />
          </GlowButton>
          <GlowButton variant="ghost">
            <Share2 className="w-5 h-5" />
          </GlowButton>
        </div>
      </motion.div>

      {/* Recording indicator */}
      <AnimatePresence>
        {isRecording && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4"
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[rgba(255,68,102,0.15)] border border-[rgba(255,68,102,0.3)]">
              <div className="w-3 h-3 rounded-full bg-[#ff4466] animate-pulse" />
              <span className="text-sm text-[#ff4466]">Recording in progress</span>
              <span className="text-xs text-[#8888aa] ml-auto">
                <Clock className="w-3 h-3 inline mr-1" />
                02:45
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content - Split View */}
      <div className="grid grid-cols-2 gap-6 h-[calc(100%-8rem)]">
        {/* Left - Live Transcript */}
        <GlassCard className="p-6 flex flex-col h-full overflow-hidden" hover={false}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-[#e0e0ff]">
              Live Transcript
            </h2>
            <span className="text-xs text-[#8888aa]">
              {transcript.length} segments
            </span>
          </div>

          {/* Speakers */}
          <div className="flex gap-2 mb-4 pb-4 border-b border-[rgba(255,255,255,0.1)]">
            {speakers.map((speaker) => (
              <div
                key={speaker.id}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[rgba(255,255,255,0.05)]"
              >
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium"
                  style={{ backgroundColor: `${speaker.color}20`, color: speaker.color }}
                >
                  {speaker.name[0]}
                </div>
                <span className="text-xs text-[#e0e0ff]">{speaker.name}</span>
              </div>
            ))}
          </div>

          {/* Transcript List */}
          <div className="flex-1 overflow-y-auto space-y-4 pr-2">
            {transcript.map((item, index) => {
              const speaker = getSpeaker(item.speaker)
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="group"
                >
                  <div className="flex gap-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0"
                      style={{
                        backgroundColor: `${speaker.color}20`,
                        color: speaker.color,
                      }}
                    >
                      {speaker.name[0]}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium" style={{ color: speaker.color }}>
                          {speaker.name}
                        </span>
                        <span className="text-xs text-[#555566]">
                          {item.timestamp}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded ${
                            item.sentiment === "positive"
                              ? "bg-[rgba(0,255,136,0.15)] text-[#00ff88]"
                              : item.sentiment === "negative"
                              ? "bg-[rgba(255,68,102,0.15)] text-[#ff4466]"
                              : "bg-[rgba(255,255,255,0.1)] text-[#8888aa]"
                          }`}
                        >
                          {item.sentiment}
                        </span>
                      </div>
                      <p className="text-sm text-[#e0e0ff] leading-relaxed">
                        {item.text}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )
            })}

            {/* Typing indicator */}
            <AnimatePresence>
              {typingIndex !== null && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex gap-3"
                >
                  <div className="w-8 h-8 rounded-full bg-[rgba(122,95,255,0.2)] flex items-center justify-center">
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#7A5FFF] animate-bounce" style={{ animationDelay: "0ms" }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-[#7A5FFF] animate-bounce" style={{ animationDelay: "150ms" }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-[#7A5FFF] animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="h-4 w-48 rounded bg-[rgba(255,255,255,0.1)] animate-pulse" />
                    <div className="h-3 w-full mt-2 rounded bg-[rgba(255,255,255,0.05)] animate-pulse" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </GlassCard>

        {/* Right - AI Summary */}
        <div className="space-y-6 h-full overflow-y-auto pr-2">
          {/* Sentiment Analysis */}
          <GlassCard className="p-6" glow="purple" delay={0.1}>
            <div className="flex items-center gap-2 mb-4">
              <Heart className="w-5 h-5 text-[#7A5FFF]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Sentiment Analysis
              </h2>
            </div>

            <div className="flex items-center gap-6 mb-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-[#00ff88]">
                  {aiSummary.sentimentAnalysis.score}%
                </div>
                <div className="text-xs text-[#8888aa]">Overall Score</div>
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888aa] w-16">Positive</span>
                  <div className="flex-1 h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${aiSummary.sentimentAnalysis.breakdown.positive}%` }}
                      transition={{ duration: 1 }}
                      className="h-full bg-[#00ff88] rounded-full"
                    />
                  </div>
                  <span className="text-xs text-[#00ff88] w-8">
                    {aiSummary.sentimentAnalysis.breakdown.positive}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888aa] w-16">Neutral</span>
                  <div className="flex-1 h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${aiSummary.sentimentAnalysis.breakdown.neutral}%` }}
                      transition={{ duration: 1, delay: 0.1 }}
                      className="h-full bg-[#8888aa] rounded-full"
                    />
                  </div>
                  <span className="text-xs text-[#8888aa] w-8">
                    {aiSummary.sentimentAnalysis.breakdown.neutral}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888aa] w-16">Negative</span>
                  <div className="flex-1 h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${aiSummary.sentimentAnalysis.breakdown.negative}%` }}
                      transition={{ duration: 1, delay: 0.2 }}
                      className="h-full bg-[#ff4466] rounded-full"
                    />
                  </div>
                  <span className="text-xs text-[#ff4466] w-8">
                    {aiSummary.sentimentAnalysis.breakdown.negative}%
                  </span>
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Key Objectives */}
          <GlassCard className="p-6" delay={0.2}>
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-[#00D9FF]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Key Objectives
              </h2>
            </div>

            <ul className="space-y-2">
              {aiSummary.keyObjectives.map((objective, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="flex items-start gap-2 text-sm text-[#e0e0ff]"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00D9FF] mt-2 flex-shrink-0" />
                  {objective}
                </motion.li>
              ))}
            </ul>
          </GlassCard>

          {/* Action Items */}
          <GlassCard className="p-6" delay={0.3}>
            <div className="flex items-center gap-2 mb-4">
              <CheckSquare className="w-5 h-5 text-[#00ff88]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Action Items
              </h2>
            </div>

            <div className="space-y-3">
              {aiSummary.actionItems.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="p-3 rounded-lg bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.05)]"
                >
                  <p className="text-sm text-[#e0e0ff] mb-2">{item.task}</p>
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1 text-[#7A5FFF]">
                      <User className="w-3 h-3" />
                      {item.assignee}
                    </span>
                    <span className="text-[#8888aa]">{item.due}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Entity Detection */}
          <GlassCard className="p-6" delay={0.4}>
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-[#7A5FFF]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Detected Entities
              </h2>
            </div>

            <div className="flex flex-wrap gap-2">
              {aiSummary.entities.map((entity, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className={`px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 ${
                    entity.type === "Organization"
                      ? "bg-[rgba(0,217,255,0.15)] text-[#00D9FF]"
                      : entity.type === "Feature"
                      ? "bg-[rgba(122,95,255,0.15)] text-[#7A5FFF]"
                      : "bg-[rgba(0,255,136,0.15)] text-[#00ff88]"
                  }`}
                >
                  {entity.type === "Organization" && <Building2 className="w-3 h-3" />}
                  {entity.type === "Feature" && <Sparkles className="w-3 h-3" />}
                  {entity.type === "Timeline" && <TrendingUp className="w-3 h-3" />}
                  {entity.value}
                </motion.span>
              ))}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}
```

---

## app/dashboard/repository/page.tsx (Cognitive Repository)

```tsx
"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Search,
  Filter,
  Calendar,
  Users,
  Tag,
  Clock,
  TrendingUp,
  ChevronDown,
  Play,
  Download,
  Trash2,
  MoreHorizontal,
  Database,
  HardDrive,
  Hash,
  FileText,
  ArrowUpRight,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"
import { StatCard } from "@/components/stat-card"

const meetings = [
  {
    id: 1,
    title: "Q4 Strategy Planning Session",
    date: "2024-01-15",
    duration: "1:23:45",
    participants: ["Sarah Chen", "Marcus Johnson", "Elena Rodriguez", "David Kim"],
    sentiment: 85,
    keywords: ["roadmap", "Q4", "enterprise", "SSO", "analytics"],
    project: "Enterprise Suite",
  },
  {
    id: 2,
    title: "Product Roadmap Review",
    date: "2024-01-14",
    duration: "45:30",
    participants: ["Elena Rodriguez", "Alex Thompson"],
    sentiment: 72,
    keywords: ["features", "timeline", "MVP", "beta"],
    project: "Mobile App",
  },
  {
    id: 3,
    title: "Client Onboarding - Acme Corp",
    date: "2024-01-13",
    duration: "32:15",
    participants: ["Sarah Chen", "Client Team"],
    sentiment: 92,
    keywords: ["onboarding", "integration", "success"],
    project: "Client Success",
  },
  {
    id: 4,
    title: "Engineering Sprint Planning",
    date: "2024-01-12",
    duration: "1:05:20",
    participants: ["Marcus Johnson", "Dev Team"],
    sentiment: 78,
    keywords: ["sprint", "tickets", "velocity", "blockers"],
    project: "Engineering",
  },
  {
    id: 5,
    title: "Marketing Campaign Review",
    date: "2024-01-11",
    duration: "52:40",
    participants: ["Marketing Team", "Elena Rodriguez"],
    sentiment: 68,
    keywords: ["campaign", "ROI", "conversion", "leads"],
    project: "Marketing",
  },
  {
    id: 6,
    title: "Security Audit Discussion",
    date: "2024-01-10",
    duration: "1:15:00",
    participants: ["Marcus Johnson", "Security Team"],
    sentiment: 75,
    keywords: ["security", "audit", "compliance", "SOC2"],
    project: "Infrastructure",
  },
]

const projects = ["All Projects", "Enterprise Suite", "Mobile App", "Client Success", "Engineering", "Marketing", "Infrastructure"]

export default function RepositoryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProject, setSelectedProject] = useState("All Projects")
  const [expandedMeeting, setExpandedMeeting] = useState<number | null>(null)

  const filteredMeetings = meetings.filter((meeting) => {
    const matchesSearch =
      meeting.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      meeting.keywords.some((k) => k.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesProject = selectedProject === "All Projects" || meeting.project === selectedProject
    return matchesSearch && matchesProject
  })

  const getSentimentColor = (score: number) => {
    if (score >= 80) return "#00ff88"
    if (score >= 60) return "#00D9FF"
    if (score >= 40) return "#ffaa00"
    return "#ff4466"
  }

  return (
    <div className="p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
          Cognitive Repository
        </h1>
        <p className="text-[#8888aa]">
          Archive and search all AI-processed intelligence sessions
        </p>
      </motion.div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Sessions Processed"
          value="128"
          icon={FileText}
          trend="up"
          trendValue="+24 this week"
          delay={0.1}
        />
        <StatCard
          label="Data Analyzed"
          value="12.4 GB"
          icon={HardDrive}
          trend="up"
          trendValue="+2.1 GB"
          delay={0.2}
        />
        <StatCard
          label="Keywords Identified"
          value="2,482"
          icon={Hash}
          trend="up"
          trendValue="+156"
          delay={0.3}
        />
        <StatCard
          label="Avg Sentiment"
          value="76%"
          icon={TrendingUp}
          trend="up"
          trendValue="+4%"
          delay={0.4}
        />
      </div>

      {/* Search and Filters */}
      <GlassCard className="p-6 mb-6" hover={false} delay={0.2}>
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8888aa]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search sessions, keywords, or participants..."
              className="w-full pl-11 pr-4 py-3 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] placeholder:text-[#555566] focus:outline-none focus:border-[#00D9FF] focus:shadow-[0_0_20px_rgba(0,217,255,0.2)] transition-all"
            />
          </div>

          {/* Filters */}
          <div className="flex gap-3">
            {/* Project Filter */}
            <div className="relative">
              <select
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
                className="appearance-none px-4 py-3 pr-10 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] focus:outline-none focus:border-[#00D9FF] cursor-pointer"
              >
                {projects.map((project) => (
                  <option key={project} value={project} className="bg-[#0a0f23]">
                    {project}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8888aa] pointer-events-none" />
            </div>

            <GlowButton variant="ghost" className="gap-2">
              <Calendar className="w-4 h-4" />
              <span>Date</span>
            </GlowButton>

            <GlowButton variant="ghost" className="gap-2">
              <Users className="w-4 h-4" />
              <span>Participants</span>
            </GlowButton>

            <GlowButton variant="ghost" className="gap-2">
              <Filter className="w-4 h-4" />
              <span>More Filters</span>
            </GlowButton>
          </div>
        </div>
      </GlassCard>

      {/* Results count */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-[#8888aa]">
          Showing {filteredMeetings.length} of {meetings.length} sessions
        </p>
        <div className="flex items-center gap-2 text-sm text-[#8888aa]">
          <Database className="w-4 h-4" />
          <span>Last synced: 2 minutes ago</span>
        </div>
      </div>

      {/* Meeting Cards */}
      <div className="space-y-4">
        {filteredMeetings.map((meeting, index) => (
          <motion.div
            key={meeting.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + index * 0.05 }}
          >
            <GlassCard
              className="p-6 cursor-pointer"
              hover
              onClick={() => setExpandedMeeting(expandedMeeting === meeting.id ? null : meeting.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-[#e0e0ff]">
                      {meeting.title}
                    </h3>
                    <span className="px-2 py-0.5 rounded text-xs bg-[rgba(122,95,255,0.15)] text-[#7A5FFF]">
                      {meeting.project}
                    </span>
                  </div>

                  <div className="flex items-center gap-6 text-sm text-[#8888aa] mb-4">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      {new Date(meeting.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {meeting.duration}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Users className="w-4 h-4" />
                      {meeting.participants.length} participants
                    </span>
                  </div>

                  {/* Keywords */}
                  <div className="flex flex-wrap gap-2">
                    {meeting.keywords.map((keyword) => (
                      <span
                        key={keyword}
                        className="px-2 py-1 rounded text-xs bg-[rgba(0,217,255,0.1)] text-[#00D9FF] flex items-center gap-1"
                      >
                        <Tag className="w-3 h-3" />
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Sentiment & Actions */}
                <div className="flex items-start gap-6">
                  {/* Sentiment Score */}
                  <div className="text-center">
                    <div className="relative w-16 h-16">
                      <svg className="w-full h-full -rotate-90">
                        <circle
                          cx="32"
                          cy="32"
                          r="28"
                          fill="none"
                          stroke="rgba(255,255,255,0.1)"
                          strokeWidth="4"
                        />
                        <motion.circle
                          cx="32"
                          cy="32"
                          r="28"
                          fill="none"
                          stroke={getSentimentColor(meeting.sentiment)}
                          strokeWidth="4"
                          strokeLinecap="round"
                          strokeDasharray={176}
                          initial={{ strokeDashoffset: 176 }}
                          animate={{ strokeDashoffset: 176 - (176 * meeting.sentiment) / 100 }}
                          transition={{ duration: 1, delay: 0.3 + index * 0.1 }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span
                          className="text-lg font-bold"
                          style={{ color: getSentimentColor(meeting.sentiment) }}
                        >
                          {meeting.sentiment}
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-[#8888aa] mt-1">Sentiment</p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <GlowButton variant="ghost" size="sm" className="w-10 h-10 p-0">
                      <Play className="w-4 h-4" />
                    </GlowButton>
                    <GlowButton variant="ghost" size="sm" className="w-10 h-10 p-0">
                      <Download className="w-4 h-4" />
                    </GlowButton>
                    <GlowButton variant="ghost" size="sm" className="w-10 h-10 p-0">
                      <MoreHorizontal className="w-4 h-4" />
                    </GlowButton>
                  </div>
                </div>
              </div>

              {/* Expanded Content */}
              <AnimatePresence>
                {expandedMeeting === meeting.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-6 pt-6 border-t border-[rgba(255,255,255,0.1)]"
                  >
                    <div className="grid grid-cols-3 gap-6">
                      {/* Participants */}
                      <div>
                        <h4 className="text-sm font-medium text-[#8888aa] mb-3">
                          Participants
                        </h4>
                        <div className="space-y-2">
                          {meeting.participants.map((participant, i) => (
                            <div
                              key={i}
                              className="flex items-center gap-2 text-sm text-[#e0e0ff]"
                            >
                              <div className="w-6 h-6 rounded-full bg-[rgba(0,217,255,0.2)] flex items-center justify-center text-xs text-[#00D9FF]">
                                {participant[0]}
                              </div>
                              {participant}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Quick Actions */}
                      <div>
                        <h4 className="text-sm font-medium text-[#8888aa] mb-3">
                          Quick Actions
                        </h4>
                        <div className="space-y-2">
                          <button className="w-full text-left px-3 py-2 rounded-lg text-sm text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)] transition-colors flex items-center gap-2">
                            <FileText className="w-4 h-4 text-[#00D9FF]" />
                            View Full Transcript
                          </button>
                          <button className="w-full text-left px-3 py-2 rounded-lg text-sm text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)] transition-colors flex items-center gap-2">
                            <ArrowUpRight className="w-4 h-4 text-[#7A5FFF]" />
                            Export Summary
                          </button>
                          <button className="w-full text-left px-3 py-2 rounded-lg text-sm text-[#ff4466] hover:bg-[rgba(255,68,102,0.1)] transition-colors flex items-center gap-2">
                            <Trash2 className="w-4 h-4" />
                            Delete Session
                          </button>
                        </div>
                      </div>

                      {/* AI Insights */}
                      <div>
                        <h4 className="text-sm font-medium text-[#8888aa] mb-3">
                          AI Insights
                        </h4>
                        <p className="text-sm text-[#e0e0ff] leading-relaxed">
                          This session demonstrated strong team alignment on Q4 priorities.
                          Key decisions included SSO integration timeline and resource allocation
                          for the analytics dashboard.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Load More */}
      {filteredMeetings.length > 0 && (
        <div className="mt-8 text-center">
          <GlowButton variant="ghost">Load More Sessions</GlowButton>
        </div>
      )}
    </div>
  )
}
```

---

## app/dashboard/settings/page.tsx (Configuration Console)

```tsx
"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Brain,
  Shield,
  Mic,
  Volume2,
  Zap,
  Key,
  Fingerprint,
  Globe,
  Bell,
  Palette,
  Code,
  RefreshCw,
  Check,
  ExternalLink,
  Sparkles,
  Cpu,
  Bot,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"

const aiModels = [
  { id: "neural-4", name: "Neural-4 Ultra", description: "Latest flagship model", recommended: true },
  { id: "neural-3", name: "Neural-3 Pro", description: "Balanced performance" },
  { id: "neural-2", name: "Neural-2 Fast", description: "Optimized for speed" },
  { id: "quantum", name: "Quantum Core", description: "Experimental quantum integration" },
]

const integrations = [
  { name: "Slack", connected: true, icon: "💬" },
  { name: "GitHub", connected: true, icon: "🔗" },
  { name: "Notion", connected: false, icon: "📝" },
  { name: "Linear", connected: false, icon: "📋" },
  { name: "Jira", connected: true, icon: "🎯" },
  { name: "Custom API", connected: false, icon: "🔌" },
]

const voiceOptions = [
  { id: "aria", name: "Aria", accent: "Neutral" },
  { id: "marcus", name: "Marcus", accent: "Professional" },
  { id: "nova", name: "Nova", accent: "Friendly" },
  { id: "alex", name: "Alex", accent: "Technical" },
]

export default function SettingsPage() {
  const [selectedModel, setSelectedModel] = useState("neural-4")
  const [selectedVoice, setSelectedVoice] = useState("aria")
  const [settings, setSettings] = useState({
    autoTranscribe: true,
    smartSummary: true,
    sentimentAnalysis: true,
    entityDetection: true,
    biometricAuth: true,
    quantumEncryption: true,
    voiceSynthesis: false,
    notifications: true,
    darkMode: true,
    betaFeatures: false,
  })

  const [encryptionLevel, setEncryptionLevel] = useState(256)
  const [processingSpeed, setProcessingSpeed] = useState(75)
  const [keyRotationStatus] = useState("Active")

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const ToggleSwitch = ({
    enabled,
    onToggle,
  }: {
    enabled: boolean
    onToggle: () => void
  }) => (
    <button
      onClick={onToggle}
      className={`relative w-12 h-6 rounded-full transition-all duration-300 ${
        enabled
          ? "bg-gradient-to-r from-[#00D9FF] to-[#7A5FFF] shadow-[0_0_15px_rgba(0,217,255,0.4)]"
          : "bg-[rgba(255,255,255,0.1)]"
      }`}
    >
      <motion.div
        animate={{ x: enabled ? 24 : 2 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        className="absolute top-1 w-4 h-4 rounded-full bg-white shadow-lg"
      />
    </button>
  )

  return (
    <div className="p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
          Configuration Console
        </h1>
        <p className="text-[#8888aa]">
          Neural engine settings and system configuration
        </p>
      </motion.div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left Column - AI Engine & Voice */}
        <div className="col-span-2 space-y-6">
          {/* AI Model Selection */}
          <GlassCard className="p-6" delay={0.1}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.15)]">
                <Brain className="w-5 h-5 text-[#00D9FF]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Neural Engine
                </h2>
                <p className="text-sm text-[#8888aa]">
                  Select your AI processing model
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {aiModels.map((model, index) => (
                <motion.button
                  key={model.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.05 }}
                  onClick={() => setSelectedModel(model.id)}
                  className={`relative p-4 rounded-xl text-left transition-all duration-300 ${
                    selectedModel === model.id
                      ? "bg-[rgba(0,217,255,0.15)] border-2 border-[#00D9FF] shadow-[0_0_20px_rgba(0,217,255,0.3)]"
                      : "bg-[rgba(255,255,255,0.03)] border-2 border-transparent hover:border-[rgba(0,217,255,0.3)]"
                  }`}
                >
                  {model.recommended && (
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] bg-[rgba(0,255,136,0.2)] text-[#00ff88]">
                      Recommended
                    </span>
                  )}
                  <div className="flex items-center gap-3 mb-2">
                    <Cpu className={`w-5 h-5 ${selectedModel === model.id ? "text-[#00D9FF]" : "text-[#8888aa]"}`} />
                    <span className={`font-medium ${selectedModel === model.id ? "text-[#00D9FF]" : "text-[#e0e0ff]"}`}>
                      {model.name}
                    </span>
                  </div>
                  <p className="text-xs text-[#8888aa]">{model.description}</p>
                  {selectedModel === model.id && (
                    <motion.div
                      layoutId="modelCheck"
                      className="absolute top-4 right-4 w-5 h-5 rounded-full bg-[#00D9FF] flex items-center justify-center"
                    >
                      <Check className="w-3 h-3 text-[#050816]" />
                    </motion.div>
                  )}
                </motion.button>
              ))}
            </div>

            {/* Processing Speed Slider */}
            <div className="mt-6 pt-6 border-t border-[rgba(255,255,255,0.1)]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-[#8888aa]">Processing Priority</span>
                <span className="text-sm text-[#00D9FF]">{processingSpeed}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={processingSpeed}
                onChange={(e) => setProcessingSpeed(Number(e.target.value))}
                className="w-full h-2 rounded-full appearance-none bg-[rgba(255,255,255,0.1)] cursor-pointer accent-[#00D9FF]"
                style={{
                  background: `linear-gradient(to right, #00D9FF ${processingSpeed}%, rgba(255,255,255,0.1) ${processingSpeed}%)`,
                }}
              />
              <div className="flex justify-between text-xs text-[#555566] mt-1">
                <span>Efficiency</span>
                <span>Performance</span>
              </div>
            </div>
          </GlassCard>

          {/* Voice Synthesis */}
          <GlassCard className="p-6" delay={0.2}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-[rgba(122,95,255,0.15)]">
                  <Volume2 className="w-5 h-5 text-[#7A5FFF]" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#e0e0ff]">
                    Voice Synthesis
                  </h2>
                  <p className="text-sm text-[#8888aa]">
                    AI voice output configuration
                  </p>
                </div>
              </div>
              <ToggleSwitch
                enabled={settings.voiceSynthesis}
                onToggle={() => toggleSetting("voiceSynthesis")}
              />
            </div>

            <div className={`grid grid-cols-4 gap-3 ${!settings.voiceSynthesis && "opacity-50 pointer-events-none"}`}>
              {voiceOptions.map((voice) => (
                <button
                  key={voice.id}
                  onClick={() => setSelectedVoice(voice.id)}
                  className={`p-4 rounded-xl text-center transition-all duration-300 ${
                    selectedVoice === voice.id
                      ? "bg-[rgba(122,95,255,0.2)] border border-[#7A5FFF] shadow-[0_0_15px_rgba(122,95,255,0.3)]"
                      : "bg-[rgba(255,255,255,0.03)] border border-transparent hover:border-[rgba(122,95,255,0.3)]"
                  }`}
                >
                  <Mic className={`w-6 h-6 mx-auto mb-2 ${selectedVoice === voice.id ? "text-[#7A5FFF]" : "text-[#8888aa]"}`} />
                  <p className={`text-sm font-medium ${selectedVoice === voice.id ? "text-[#7A5FFF]" : "text-[#e0e0ff]"}`}>
                    {voice.name}
                  </p>
                  <p className="text-xs text-[#555566]">{voice.accent}</p>
                </button>
              ))}
            </div>
          </GlassCard>

          {/* Feature Toggles */}
          <GlassCard className="p-6" delay={0.3}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[rgba(0,255,136,0.15)]">
                <Sparkles className="w-5 h-5 text-[#00ff88]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  AI Features
                </h2>
                <p className="text-sm text-[#8888aa]">
                  Enable or disable intelligent features
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { key: "autoTranscribe", label: "Auto Transcription", description: "Automatically transcribe all sessions", icon: Mic },
                { key: "smartSummary", label: "Smart Summary", description: "Generate AI summaries after sessions", icon: Brain },
                { key: "sentimentAnalysis", label: "Sentiment Analysis", description: "Analyze emotional tone in conversations", icon: Bot },
                { key: "entityDetection", label: "Entity Detection", description: "Identify people, places, and topics", icon: Zap },
              ].map((feature, index) => (
                <motion.div
                  key={feature.key}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.05 }}
                  className="flex items-center justify-between p-4 rounded-xl bg-[rgba(255,255,255,0.02)]"
                >
                  <div className="flex items-center gap-3">
                    <feature.icon className="w-5 h-5 text-[#8888aa]" />
                    <div>
                      <p className="text-sm font-medium text-[#e0e0ff]">{feature.label}</p>
                      <p className="text-xs text-[#555566]">{feature.description}</p>
                    </div>
                  </div>
                  <ToggleSwitch
                    enabled={settings[feature.key as keyof typeof settings] as boolean}
                    onToggle={() => toggleSetting(feature.key as keyof typeof settings)}
                  />
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Integrations */}
          <GlassCard className="p-6" delay={0.4}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.15)]">
                  <Globe className="w-5 h-5 text-[#00D9FF]" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#e0e0ff]">
                    Integrations
                  </h2>
                  <p className="text-sm text-[#8888aa]">
                    Connect external services
                  </p>
                </div>
              </div>
              <GlowButton variant="ghost" size="sm">
                <Code className="w-4 h-4" />
                <span>API Docs</span>
              </GlowButton>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {integrations.map((integration, index) => (
                <motion.div
                  key={integration.name}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    integration.connected
                      ? "bg-[rgba(0,255,136,0.08)] border border-[rgba(0,255,136,0.2)]"
                      : "bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.08)]"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl">{integration.icon}</span>
                    {integration.connected ? (
                      <span className="flex items-center gap-1 text-xs text-[#00ff88]">
                        <Check className="w-3 h-3" />
                        Connected
                      </span>
                    ) : (
                      <button className="text-xs text-[#00D9FF] hover:underline flex items-center gap-1">
                        Connect
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <p className="text-sm font-medium text-[#e0e0ff]">{integration.name}</p>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Right Column - Security */}
        <div className="space-y-6">
          {/* Security Settings */}
          <GlassCard className="p-6" glow="purple" delay={0.15}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[rgba(122,95,255,0.15)]">
                <Shield className="w-5 h-5 text-[#7A5FFF]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Security
                </h2>
                <p className="text-sm text-[#8888aa]">
                  Enterprise security settings
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Biometric */}
              <div className="flex items-center justify-between p-3 rounded-lg bg-[rgba(255,255,255,0.03)]">
                <div className="flex items-center gap-3">
                  <Fingerprint className="w-5 h-5 text-[#7A5FFF]" />
                  <div>
                    <p className="text-sm font-medium text-[#e0e0ff]">Biometric Auth</p>
                    <p className="text-xs text-[#555566]">Fingerprint & Face ID</p>
                  </div>
                </div>
                <ToggleSwitch
                  enabled={settings.biometricAuth}
                  onToggle={() => toggleSetting("biometricAuth")}
                />
              </div>

              {/* Quantum Encryption */}
              <div className="flex items-center justify-between p-3 rounded-lg bg-[rgba(255,255,255,0.03)]">
                <div className="flex items-center gap-3">
                  <Key className="w-5 h-5 text-[#00D9FF]" />
                  <div>
                    <p className="text-sm font-medium text-[#e0e0ff]">Quantum Encryption</p>
                    <p className="text-xs text-[#555566]">Next-gen security</p>
                  </div>
                </div>
                <ToggleSwitch
                  enabled={settings.quantumEncryption}
                  onToggle={() => toggleSetting("quantumEncryption")}
                />
              </div>
            </div>

            {/* Encryption Level */}
            <div className="mt-6 pt-4 border-t border-[rgba(255,255,255,0.1)]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-[#8888aa]">Encryption Level</span>
                <span className="text-sm text-[#7A5FFF]">{encryptionLevel}-bit</span>
              </div>
              <div className="flex gap-2">
                {[128, 192, 256, 512].map((level) => (
                  <button
                    key={level}
                    onClick={() => setEncryptionLevel(level)}
                    className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                      encryptionLevel === level
                        ? "bg-[rgba(122,95,255,0.3)] text-[#7A5FFF] shadow-[0_0_10px_rgba(122,95,255,0.3)]"
                        : "bg-[rgba(255,255,255,0.05)] text-[#8888aa] hover:bg-[rgba(255,255,255,0.1)]"
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Key Rotation Status */}
            <div className="mt-4 p-3 rounded-lg bg-[rgba(0,255,136,0.1)] border border-[rgba(0,255,136,0.2)]">
              <div className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-[#00ff88]" />
                <span className="text-sm text-[#00ff88]">Quantum Key Rotation: {keyRotationStatus}</span>
              </div>
              <p className="text-xs text-[#8888aa] mt-1">Last rotation: 4 hours ago</p>
            </div>
          </GlassCard>

          {/* Notifications */}
          <GlassCard className="p-6" delay={0.25}>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-[rgba(255,170,0,0.15)]">
                <Bell className="w-5 h-5 text-[#ffaa00]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Notifications
                </h2>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-sm text-[#8888aa]">Enable notifications</p>
              <ToggleSwitch
                enabled={settings.notifications}
                onToggle={() => toggleSetting("notifications")}
              />
            </div>
          </GlassCard>

          {/* Appearance */}
          <GlassCard className="p-6" delay={0.35}>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.15)]">
                <Palette className="w-5 h-5 text-[#00D9FF]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Appearance
                </h2>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm text-[#8888aa]">Dark Mode</p>
                <ToggleSwitch
                  enabled={settings.darkMode}
                  onToggle={() => toggleSetting("darkMode")}
                />
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm text-[#8888aa]">Beta Features</p>
                <ToggleSwitch
                  enabled={settings.betaFeatures}
                  onToggle={() => toggleSetting("betaFeatures")}
                />
              </div>
            </div>
          </GlassCard>

          {/* Save Button */}
          <GlowButton className="w-full" size="lg">
            <Check className="w-5 h-5" />
            <span>Save Configuration</span>
          </GlowButton>
        </div>
      </div>
    </div>
  )
}
```

---

## components/neural-background.tsx

```tsx
"use client"

import { useEffect, useRef } from "react"

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  radius: number
  opacity: number
}

export function NeuralBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let particles: Particle[] = []
    const particleCount = 80
    const connectionDistance = 150
    const mouseRadius = 200

    const mouse = { x: -1000, y: -1000 }

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      initParticles()
    }

    const initParticles = () => {
      particles = []
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          radius: Math.random() * 2 + 1,
          opacity: Math.random() * 0.5 + 0.2,
        })
      }
    }

    const drawParticle = (particle: Particle) => {
      ctx.beginPath()
      ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(0, 217, 255, ${particle.opacity})`
      ctx.fill()

      // Add glow effect
      ctx.beginPath()
      ctx.arc(particle.x, particle.y, particle.radius * 3, 0, Math.PI * 2)
      const gradient = ctx.createRadialGradient(
        particle.x,
        particle.y,
        0,
        particle.x,
        particle.y,
        particle.radius * 3
      )
      gradient.addColorStop(0, `rgba(0, 217, 255, ${particle.opacity * 0.3})`)
      gradient.addColorStop(1, "rgba(0, 217, 255, 0)")
      ctx.fillStyle = gradient
      ctx.fill()
    }

    const drawConnections = () => {
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x
          const dy = particles[i].y - particles[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < connectionDistance) {
            const opacity = (1 - distance / connectionDistance) * 0.3
            ctx.beginPath()
            ctx.moveTo(particles[i].x, particles[i].y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.strokeStyle = `rgba(0, 217, 255, ${opacity})`
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        }
      }
    }

    const updateParticles = () => {
      for (const particle of particles) {
        // Mouse interaction
        const dx = mouse.x - particle.x
        const dy = mouse.y - particle.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < mouseRadius) {
          const force = (mouseRadius - distance) / mouseRadius
          particle.vx -= (dx / distance) * force * 0.02
          particle.vy -= (dy / distance) * force * 0.02
        }

        particle.x += particle.vx
        particle.y += particle.vy

        // Bounce off edges
        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1

        // Keep within bounds
        particle.x = Math.max(0, Math.min(canvas.width, particle.x))
        particle.y = Math.max(0, Math.min(canvas.height, particle.y))

        // Damping
        particle.vx *= 0.99
        particle.vy *= 0.99
      }
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw gradient background overlay
      const bgGradient = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        0,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width / 2
      )
      bgGradient.addColorStop(0, "rgba(122, 95, 255, 0.05)")
      bgGradient.addColorStop(1, "rgba(5, 8, 22, 0)")
      ctx.fillStyle = bgGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      drawConnections()
      for (const particle of particles) {
        drawParticle(particle)
      }
      updateParticles()

      animationFrameId = requestAnimationFrame(animate)
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX
      mouse.y = e.clientY
    }

    const handleMouseLeave = () => {
      mouse.x = -1000
      mouse.y = -1000
    }

    window.addEventListener("resize", resizeCanvas)
    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("mouseleave", handleMouseLeave)

    resizeCanvas()
    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseleave", handleMouseLeave)
      cancelAnimationFrame(animationFrameId)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ background: "transparent" }}
    />
  )
}
```

---

## components/glass-card.tsx

```tsx
"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface GlassCardProps {
  children: React.ReactNode
  className?: string
  hover?: boolean
  glow?: "blue" | "purple" | "none"
  delay?: number
}

export function GlassCard({
  children,
  className,
  hover = true,
  glow = "blue",
  delay = 0,
}: GlassCardProps) {
  const glowClasses = {
    blue: "hover:shadow-[0_0_30px_rgba(0,217,255,0.3)] hover:border-[rgba(0,217,255,0.4)]",
    purple: "hover:shadow-[0_0_30px_rgba(122,95,255,0.3)] hover:border-[rgba(122,95,255,0.4)]",
    none: "",
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      whileHover={hover ? { scale: 1.02, y: -5 } : undefined}
      className={cn(
        "relative overflow-hidden rounded-xl",
        "bg-[rgba(255,255,255,0.04)] backdrop-blur-xl",
        "border border-[rgba(0,217,255,0.15)]",
        "transition-all duration-300",
        hover && glowClasses[glow],
        className
      )}
    >
      {/* Shimmer effect */}
      <div className="absolute inset-0 animate-shimmer opacity-50" />
      <div className="relative z-10">{children}</div>
    </motion.div>
  )
}
```

---

## components/glow-button.tsx

```tsx
"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import { forwardRef } from "react"

interface GlowButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost"
  size?: "sm" | "md" | "lg"
  glow?: boolean
  children: React.ReactNode
}

export const GlowButton = forwardRef<HTMLButtonElement, GlowButtonProps>(
  ({ className, variant = "primary", size = "md", glow = true, children, ...props }, ref) => {
    const variants = {
      primary: cn(
        "bg-gradient-to-r from-[#00D9FF] to-[#00B4D8]",
        "text-[#050816] font-semibold",
        "border border-[#00D9FF]",
        glow && "shadow-[0_0_20px_rgba(0,217,255,0.4)]",
        "hover:shadow-[0_0_30px_rgba(0,217,255,0.6)]"
      ),
      secondary: cn(
        "bg-[rgba(122,95,255,0.15)]",
        "text-[#7A5FFF]",
        "border border-[rgba(122,95,255,0.3)]",
        glow && "shadow-[0_0_15px_rgba(122,95,255,0.2)]",
        "hover:shadow-[0_0_25px_rgba(122,95,255,0.4)]",
        "hover:bg-[rgba(122,95,255,0.25)]"
      ),
      ghost: cn(
        "bg-transparent",
        "text-[#e0e0ff]",
        "border border-[rgba(255,255,255,0.1)]",
        "hover:bg-[rgba(255,255,255,0.05)]",
        "hover:border-[rgba(0,217,255,0.3)]"
      ),
    }

    const sizes = {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-8 py-4 text-lg",
    }

    return (
      <motion.button
        ref={ref}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.98 }}
        className={cn(
          "relative overflow-hidden rounded-lg",
          "transition-all duration-300",
          "flex items-center justify-center gap-2",
          "disabled:opacity-50 disabled:cursor-not-allowed",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {/* Shimmer overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full hover:translate-x-full transition-transform duration-700" />
        <span className="relative z-10">{children}</span>
      </motion.button>
    )
  }
)

GlowButton.displayName = "GlowButton"
```

---

## components/stat-card.tsx

```tsx
"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface StatCardProps {
  label: string
  value: string
  icon?: LucideIcon
  trend?: "up" | "down" | "neutral"
  trendValue?: string
  delay?: number
  className?: string
}

export function StatCard({
  label,
  value,
  icon: Icon,
  trend,
  trendValue,
  delay = 0,
  className,
}: StatCardProps) {
  const trendColors = {
    up: "text-[#00ff88]",
    down: "text-[#ff4466]",
    neutral: "text-[#8888aa]",
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay }}
      whileHover={{ scale: 1.03, y: -3 }}
      className={cn(
        "relative p-4 rounded-xl",
        "bg-[rgba(255,255,255,0.04)] backdrop-blur-xl",
        "border border-[rgba(0,217,255,0.15)]",
        "transition-all duration-300",
        "hover:shadow-[0_0_25px_rgba(0,217,255,0.2)]",
        "hover:border-[rgba(0,217,255,0.3)]",
        className
      )}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-[#8888aa] uppercase tracking-wider mb-1">
            {label}
          </p>
          <p className="text-2xl font-bold text-[#00D9FF] text-glow">
            {value}
          </p>
          {trend && trendValue && (
            <p className={cn("text-xs mt-1", trendColors[trend])}>
              {trend === "up" ? "↑" : trend === "down" ? "↓" : "→"} {trendValue}
            </p>
          )}
        </div>
        {Icon && (
          <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.1)]">
            <Icon className="w-5 h-5 text-[#00D9FF]" />
          </div>
        )}
      </div>

      {/* Corner accent */}
      <div className="absolute top-0 right-0 w-16 h-16 overflow-hidden rounded-tr-xl">
        <div className="absolute top-0 right-0 w-8 h-8 bg-gradient-to-bl from-[rgba(0,217,255,0.2)] to-transparent" />
      </div>
    </motion.div>
  )
}
```

---

## components/dashboard-sidebar.tsx

```tsx
"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import {
  Brain,
  Command,
  FileText,
  Database,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"

const navItems = [
  {
    label: "Command Center",
    href: "/dashboard",
    icon: Command,
  },
  {
    label: "Live Transcript",
    href: "/dashboard/transcript",
    icon: FileText,
  },
  {
    label: "Cognitive Repository",
    href: "/dashboard/repository",
    icon: Database,
  },
  {
    label: "Configuration",
    href: "/dashboard/settings",
    icon: Settings,
  },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <motion.aside
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className={cn(
        "fixed left-0 top-0 h-full z-50",
        "bg-[rgba(10,15,35,0.95)] backdrop-blur-xl",
        "border-r border-[rgba(0,217,255,0.1)]",
        "flex flex-col",
        "transition-all duration-300",
        collapsed ? "w-20" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="p-6 border-b border-[rgba(0,217,255,0.1)]">
        <Link href="/" className="flex items-center gap-3">
          <div className="relative flex-shrink-0">
            <Brain className="w-8 h-8 text-[#00D9FF]" />
            <div className="absolute inset-0 blur-md bg-[#00D9FF]/30" />
          </div>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-lg font-bold"
            >
              <span className="text-[#00D9FF]">COGNITIVE</span>
              <span className="text-[#e0e0ff]"> AI</span>
            </motion.span>
          )}
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item, index) => {
          const isActive = pathname === item.href
          return (
            <motion.div
              key={item.href}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl",
                  "transition-all duration-300",
                  "group relative overflow-hidden",
                  isActive
                    ? "bg-[rgba(0,217,255,0.15)] text-[#00D9FF] shadow-[0_0_20px_rgba(0,217,255,0.2)]"
                    : "text-[#8888aa] hover:text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)]"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute left-0 top-0 bottom-0 w-1 bg-[#00D9FF] rounded-r"
                  />
                )}
                <item.icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-glow")} />
                {!collapsed && (
                  <span className="text-sm font-medium">{item.label}</span>
                )}
              </Link>
            </motion.div>
          )
        })}
      </nav>

      {/* Status indicator */}
      <div className="p-4 border-t border-[rgba(0,217,255,0.1)]">
        {!collapsed && (
          <div className="mb-4 p-3 rounded-lg bg-[rgba(0,255,136,0.1)] border border-[rgba(0,255,136,0.2)]">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#00ff88] animate-pulse" />
              <span className="text-xs text-[#00ff88]">System Online</span>
            </div>
            <p className="text-[10px] text-[#8888aa] mt-1">Neural Core Active</p>
          </div>
        )}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-[#8888aa] hover:text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)] transition-all"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <>
              <ChevronLeft className="w-5 h-5" />
              <span className="text-sm">Collapse</span>
            </>
          )}
        </button>
      </div>

      {/* Logout */}
      <div className="p-4 border-t border-[rgba(0,217,255,0.1)]">
        <Link
          href="/"
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#8888aa] hover:text-[#ff4466] hover:bg-[rgba(255,68,102,0.1)] transition-all"
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span className="text-sm">Disconnect</span>}
        </Link>
      </div>
    </motion.aside>
  )
}
```

---

## components/audio-waveform.tsx

```tsx
"use client"

import { motion } from "framer-motion"
import { useEffect, useState } from "react"

interface AudioWaveformProps {
  isActive?: boolean
  barCount?: number
  className?: string
}

export function AudioWaveform({
  isActive = false,
  barCount = 40,
  className,
}: AudioWaveformProps) {
  const [heights, setHeights] = useState<number[]>([])

  useEffect(() => {
    const generateHeights = () => {
      if (!isActive) {
        setHeights(Array(barCount).fill(10))
        return
      }

      setHeights(
        Array(barCount)
          .fill(0)
          .map(() => Math.random() * 80 + 20)
      )
    }

    generateHeights()
    const interval = setInterval(generateHeights, 100)

    return () => clearInterval(interval)
  }, [isActive, barCount])

  return (
    <div className={className}>
      <div className="flex items-center justify-center gap-1 h-24">
        {heights.map((height, index) => {
          const isCenter = index > barCount / 3 && index < (barCount * 2) / 3
          return (
            <motion.div
              key={index}
              animate={{ height: `${height}%` }}
              transition={{
                duration: 0.1,
                ease: "easeInOut",
              }}
              className="w-1 rounded-full"
              style={{
                background: isCenter
                  ? "linear-gradient(to top, #00D9FF, #7A5FFF)"
                  : "linear-gradient(to top, rgba(0,217,255,0.3), rgba(122,95,255,0.3))",
                boxShadow: isActive && isCenter
                  ? "0 0 10px rgba(0,217,255,0.5)"
                  : "none",
              }}
            />
          )
        })}
      </div>
    </div>
  )
}
```

---

## Dependencies (package.json additions)

```json
{
  "dependencies": {
    "framer-motion": "^11.x",
    "lucide-react": "^0.x"
  }
}
```

Install with:
```bash
pnpm add framer-motion lucide-react
```
