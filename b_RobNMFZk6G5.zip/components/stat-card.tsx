"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface StatCardProps {
  label: string
  value: string
  icon?: LucideIcon
  trend?: "up" | "down" | "neutral"
  trendValue?: string
  delay?: number
  className?: string
}

export function StatCard({
  label,
  value,
  icon: Icon,
  trend,
  trendValue,
  delay = 0,
  className,
}: StatCardProps) {
  const trendColors = {
    up: "text-[#00ff88]",
    down: "text-[#ff4466]",
    neutral: "text-[#8888aa]",
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay }}
      whileHover={{ scale: 1.03, y: -3 }}
      className={cn(
        "relative p-4 rounded-xl",
        "bg-[rgba(255,255,255,0.04)] backdrop-blur-xl",
        "border border-[rgba(0,217,255,0.15)]",
        "transition-all duration-300",
        "hover:shadow-[0_0_25px_rgba(0,217,255,0.2)]",
        "hover:border-[rgba(0,217,255,0.3)]",
        className
      )}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-[#8888aa] uppercase tracking-wider mb-1">
            {label}
          </p>
          <p className="text-2xl font-bold text-[#00D9FF] text-glow">
            {value}
          </p>
          {trend && trendValue && (
            <p className={cn("text-xs mt-1", trendColors[trend])}>
              {trend === "up" ? "↑" : trend === "down" ? "↓" : "→"} {trendValue}
            </p>
          )}
        </div>
        {Icon && (
          <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.1)]">
            <Icon className="w-5 h-5 text-[#00D9FF]" />
          </div>
        )}
      </div>

      {/* Corner accent */}
      <div className="absolute top-0 right-0 w-16 h-16 overflow-hidden rounded-tr-xl">
        <div className="absolute top-0 right-0 w-8 h-8 bg-gradient-to-bl from-[rgba(0,217,255,0.2)] to-transparent" />
      </div>
    </motion.div>
  )
}
