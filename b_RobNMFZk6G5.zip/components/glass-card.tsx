"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface GlassCardProps {
  children: React.ReactNode
  className?: string
  hover?: boolean
  glow?: "blue" | "purple" | "none"
  delay?: number
}

export function GlassCard({
  children,
  className,
  hover = true,
  glow = "blue",
  delay = 0,
}: GlassCardProps) {
  const glowClasses = {
    blue: "hover:shadow-[0_0_30px_rgba(0,217,255,0.3)] hover:border-[rgba(0,217,255,0.4)]",
    purple: "hover:shadow-[0_0_30px_rgba(122,95,255,0.3)] hover:border-[rgba(122,95,255,0.4)]",
    none: "",
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      whileHover={hover ? { scale: 1.02, y: -5 } : undefined}
      className={cn(
        "relative overflow-hidden rounded-xl",
        "bg-[rgba(255,255,255,0.04)] backdrop-blur-xl",
        "border border-[rgba(0,217,255,0.15)]",
        "transition-all duration-300",
        hover && glowClasses[glow],
        className
      )}
    >
      {/* Shimmer effect */}
      <div className="absolute inset-0 animate-shimmer opacity-50" />
      <div className="relative z-10">{children}</div>
    </motion.div>
  )
}
