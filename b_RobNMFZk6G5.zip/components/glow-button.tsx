"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import { forwardRef } from "react"

interface GlowButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost"
  size?: "sm" | "md" | "lg"
  glow?: boolean
  children: React.ReactNode
}

export const GlowButton = forwardRef<HTMLButtonElement, GlowButtonProps>(
  ({ className, variant = "primary", size = "md", glow = true, children, ...props }, ref) => {
    const variants = {
      primary: cn(
        "bg-gradient-to-r from-[#00D9FF] to-[#00B4D8]",
        "text-[#050816] font-semibold",
        "border border-[#00D9FF]",
        glow && "shadow-[0_0_20px_rgba(0,217,255,0.4)]",
        "hover:shadow-[0_0_30px_rgba(0,217,255,0.6)]"
      ),
      secondary: cn(
        "bg-[rgba(122,95,255,0.15)]",
        "text-[#7A5FFF]",
        "border border-[rgba(122,95,255,0.3)]",
        glow && "shadow-[0_0_15px_rgba(122,95,255,0.2)]",
        "hover:shadow-[0_0_25px_rgba(122,95,255,0.4)]",
        "hover:bg-[rgba(122,95,255,0.25)]"
      ),
      ghost: cn(
        "bg-transparent",
        "text-[#e0e0ff]",
        "border border-[rgba(255,255,255,0.1)]",
        "hover:bg-[rgba(255,255,255,0.05)]",
        "hover:border-[rgba(0,217,255,0.3)]"
      ),
    }

    const sizes = {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-8 py-4 text-lg",
    }

    return (
      <motion.button
        ref={ref}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.98 }}
        className={cn(
          "relative overflow-hidden rounded-lg",
          "transition-all duration-300",
          "flex items-center justify-center gap-2",
          "disabled:opacity-50 disabled:cursor-not-allowed",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {/* Shimmer overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full hover:translate-x-full transition-transform duration-700" />
        <span className="relative z-10">{children}</span>
      </motion.button>
    )
  }
)

GlowButton.displayName = "GlowButton"
