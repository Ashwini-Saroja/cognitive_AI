"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import {
  Brain,
  Command,
  FileText,
  Database,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"

const navItems = [
  {
    label: "Command Center",
    href: "/dashboard",
    icon: Command,
  },
  {
    label: "Live Transcript",
    href: "/dashboard/transcript",
    icon: FileText,
  },
  {
    label: "Cognitive Repository",
    href: "/dashboard/repository",
    icon: Database,
  },
  {
    label: "Configuration",
    href: "/dashboard/settings",
    icon: Settings,
  },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <motion.aside
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className={cn(
        "fixed left-0 top-0 h-full z-50",
        "bg-[rgba(10,15,35,0.95)] backdrop-blur-xl",
        "border-r border-[rgba(0,217,255,0.1)]",
        "flex flex-col",
        "transition-all duration-300",
        collapsed ? "w-20" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="p-6 border-b border-[rgba(0,217,255,0.1)]">
        <Link href="/" className="flex items-center gap-3">
          <div className="relative flex-shrink-0">
            <Brain className="w-8 h-8 text-[#00D9FF]" />
            <div className="absolute inset-0 blur-md bg-[#00D9FF]/30" />
          </div>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-lg font-bold"
            >
              <span className="text-[#00D9FF]">COGNITIVE</span>
              <span className="text-[#e0e0ff]"> AI</span>
            </motion.span>
          )}
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item, index) => {
          const isActive = pathname === item.href
          return (
            <motion.div
              key={item.href}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl",
                  "transition-all duration-300",
                  "group relative overflow-hidden",
                  isActive
                    ? "bg-[rgba(0,217,255,0.15)] text-[#00D9FF] shadow-[0_0_20px_rgba(0,217,255,0.2)]"
                    : "text-[#8888aa] hover:text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)]"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute left-0 top-0 bottom-0 w-1 bg-[#00D9FF] rounded-r"
                  />
                )}
                <item.icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-glow")} />
                {!collapsed && (
                  <span className="text-sm font-medium">{item.label}</span>
                )}
              </Link>
            </motion.div>
          )
        })}
      </nav>

      {/* Status indicator */}
      <div className="p-4 border-t border-[rgba(0,217,255,0.1)]">
        {!collapsed && (
          <div className="mb-4 p-3 rounded-lg bg-[rgba(0,255,136,0.1)] border border-[rgba(0,255,136,0.2)]">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#00ff88] animate-pulse" />
              <span className="text-xs text-[#00ff88]">System Online</span>
            </div>
            <p className="text-[10px] text-[#8888aa] mt-1">Neural Core Active</p>
          </div>
        )}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-[#8888aa] hover:text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)] transition-all"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <>
              <ChevronLeft className="w-5 h-5" />
              <span className="text-sm">Collapse</span>
            </>
          )}
        </button>
      </div>

      {/* Logout */}
      <div className="p-4 border-t border-[rgba(0,217,255,0.1)]">
        <Link
          href="/"
          className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#8888aa] hover:text-[#ff4466] hover:bg-[rgba(255,68,102,0.1)] transition-all"
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span className="text-sm">Disconnect</span>}
        </Link>
      </div>
    </motion.aside>
  )
}
