"use client"

import { motion } from "framer-motion"
import { useEffect, useState } from "react"

interface AudioWaveformProps {
  isActive?: boolean
  barCount?: number
  className?: string
}

export function AudioWaveform({
  isActive = false,
  barCount = 40,
  className,
}: AudioWaveformProps) {
  const [heights, setHeights] = useState<number[]>([])

  useEffect(() => {
    const generateHeights = () => {
      if (!isActive) {
        setHeights(Array(barCount).fill(10))
        return
      }

      setHeights(
        Array(barCount)
          .fill(0)
          .map(() => Math.random() * 80 + 20)
      )
    }

    generateHeights()
    const interval = setInterval(generateHeights, 100)

    return () => clearInterval(interval)
  }, [isActive, barCount])

  return (
    <div className={className}>
      <div className="flex items-center justify-center gap-1 h-24">
        {heights.map((height, index) => {
          const isCenter = index > barCount / 3 && index < (barCount * 2) / 3
          return (
            <motion.div
              key={index}
              animate={{ height: `${height}%` }}
              transition={{
                duration: 0.1,
                ease: "easeInOut",
              }}
              className="w-1 rounded-full"
              style={{
                background: isCenter
                  ? "linear-gradient(to top, #00D9FF, #7A5FFF)"
                  : "linear-gradient(to top, rgba(0,217,255,0.3), rgba(122,95,255,0.3))",
                boxShadow: isActive && isCenter
                  ? "0 0 10px rgba(0,217,255,0.5)"
                  : "none",
              }}
            />
          )
        })}
      </div>
    </div>
  )
}
