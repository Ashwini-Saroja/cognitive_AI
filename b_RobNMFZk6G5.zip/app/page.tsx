"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Brain,
  Fingerprint,
  Zap,
  Shield,
  Cpu,
  Mail,
  Lock,
  ArrowRight,
  Sparkles,
} from "lucide-react"
import { NeuralBackground } from "@/components/neural-background"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"
import { StatCard } from "@/components/stat-card"
import Link from "next/link"

export default function OnboardingPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#050816]">
      <NeuralBackground />

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#050816]/50 to-[#050816] pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-[radial-gradient(ellipse_at_center,rgba(122,95,255,0.15)_0%,transparent_70%)] pointer-events-none" />

      <div className="relative z-10 container mx-auto px-4 py-8 min-h-screen flex flex-col">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-between mb-12"
        >
          <div className="flex items-center gap-3">
            <div className="relative">
              <Brain className="w-10 h-10 text-[#00D9FF]" />
              <div className="absolute inset-0 blur-lg bg-[#00D9FF]/40" />
            </div>
            <span className="text-2xl font-bold tracking-tight">
              <span className="text-[#00D9FF] text-glow">COGNITIVE</span>
              <span className="text-[#e0e0ff]"> AI</span>
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-[#8888aa] hover:text-[#00D9FF] transition-colors text-sm">
              Enterprise
            </a>
            <a href="#" className="text-[#8888aa] hover:text-[#00D9FF] transition-colors text-sm">
              Documentation
            </a>
            <a href="#" className="text-[#8888aa] hover:text-[#00D9FF] transition-colors text-sm">
              Security
            </a>
          </nav>
        </motion.header>

        {/* Main Content */}
        <div className="flex-1 flex items-center justify-center">
          <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Hero content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[rgba(122,95,255,0.15)] border border-[rgba(122,95,255,0.3)]"
                >
                  <Sparkles className="w-4 h-4 text-[#7A5FFF]" />
                  <span className="text-sm text-[#7A5FFF]">Neural Intelligence Suite v4.0</span>
                </motion.div>

                <h1 className="text-5xl lg:text-6xl font-bold leading-tight text-balance">
                  <span className="text-[#e0e0ff]">The Future of </span>
                  <span className="text-[#00D9FF] text-glow">Neural Intelligence</span>
                </h1>

                <p className="text-xl text-[#8888aa] leading-relaxed max-w-lg">
                  An end-to-end Executive Intelligence suite powered by quantum-enhanced AI systems and neural processing networks.
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4">
                <StatCard
                  label="Latency"
                  value="12ms"
                  icon={Zap}
                  delay={0.4}
                />
                <StatCard
                  label="Encryption"
                  value="Quantum"
                  icon={Shield}
                  delay={0.5}
                />
                <StatCard
                  label="Efficiency"
                  value="99.2%"
                  icon={Cpu}
                  delay={0.6}
                />
              </div>

              {/* Features */}
              <div className="flex flex-wrap gap-3">
                {["Neural Processing", "Real-time Analytics", "Enterprise Security", "Multi-modal AI"].map(
                  (feature, index) => (
                    <motion.span
                      key={feature}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: 0.7 + index * 0.1 }}
                      className="px-3 py-1.5 text-sm text-[#8888aa] bg-[rgba(255,255,255,0.04)] rounded-lg border border-[rgba(255,255,255,0.08)]"
                    >
                      {feature}
                    </motion.span>
                  )
                )}
              </div>
            </motion.div>

            {/* Right side - Login card */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
            >
              <GlassCard className="p-8" hover={false}>
                <div className="space-y-6">
                  <div className="text-center space-y-2">
                    <h2 className="text-2xl font-bold text-[#e0e0ff]">
                      Access Neural Console
                    </h2>
                    <p className="text-[#8888aa] text-sm">
                      Secure enterprise authentication required
                    </p>
                  </div>

                  <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                    <div className="space-y-2">
                      <label className="text-sm text-[#8888aa]">Email Address</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8888aa]" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="executive@enterprise.com"
                          className="w-full pl-11 pr-4 py-3 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] placeholder:text-[#555566] focus:outline-none focus:border-[#00D9FF] focus:shadow-[0_0_20px_rgba(0,217,255,0.2)] transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-[#8888aa]">Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8888aa]" />
                        <input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Enter secure passkey"
                          className="w-full pl-11 pr-4 py-3 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] placeholder:text-[#555566] focus:outline-none focus:border-[#00D9FF] focus:shadow-[0_0_20px_rgba(0,217,255,0.2)] transition-all"
                        />
                      </div>
                    </div>

                    <Link href="/dashboard">
                      <GlowButton className="w-full" size="lg">
                        <span>Initialize Session</span>
                        <ArrowRight className="w-5 h-5" />
                      </GlowButton>
                    </Link>
                  </form>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-[rgba(255,255,255,0.1)]" />
                    </div>
                    <div className="relative flex justify-center text-xs">
                      <span className="px-4 bg-[#0a0f23] text-[#555566]">
                        or continue with
                      </span>
                    </div>
                  </div>

                  <GlowButton variant="secondary" className="w-full" size="md">
                    <Fingerprint className="w-5 h-5" />
                    <span>Biometric Authentication</span>
                  </GlowButton>

                  <p className="text-center text-sm text-[#555566]">
                    {"Don't have access?"}{" "}
                    <a href="#" className="text-[#00D9FF] hover:underline">
                      Request Enterprise Access
                    </a>
                  </p>
                </div>
              </GlassCard>

              {/* Security badge */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="mt-4 flex items-center justify-center gap-2 text-xs text-[#555566]"
              >
                <Shield className="w-4 h-4" />
                <span>Protected by Quantum Encryption Protocol</span>
              </motion.div>
            </motion.div>
          </div>
        </div>

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-center text-xs text-[#555566] mt-8"
        >
          <p>Cognitive AI Neural Intelligence Suite - Enterprise Edition</p>
          <p className="mt-1">Quantum-secured • SOC 2 Certified • GDPR Compliant</p>
        </motion.footer>
      </div>
    </main>
  )
}
