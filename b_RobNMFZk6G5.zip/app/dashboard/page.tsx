"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Play,
  Pause,
  Mic,
  Activity,
  Zap,
  Shield,
  Clock,
  TrendingUp,
  MessageSquare,
  BarChart3,
  Users,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"
import { StatCard } from "@/components/stat-card"
import { AudioWaveform } from "@/components/audio-waveform"

const recentConversations = [
  {
    id: 1,
    title: "Q4 Strategy Meeting",
    participants: 4,
    duration: "45:23",
    sentiment: "positive",
    time: "2 hours ago",
  },
  {
    id: 2,
    title: "Product Roadmap Review",
    participants: 6,
    duration: "1:12:45",
    sentiment: "neutral",
    time: "5 hours ago",
  },
  {
    id: 3,
    title: "Client Onboarding Call",
    participants: 3,
    duration: "32:10",
    sentiment: "positive",
    time: "Yesterday",
  },
]

const activityTimeline = [
  { time: "14:32", event: "Session initialized", type: "start" },
  { time: "14:33", event: "Neural processing active", type: "process" },
  { time: "14:35", event: "Summary generated", type: "complete" },
  { time: "14:36", event: "Action items extracted", type: "complete" },
  { time: "14:40", event: "Session archived", type: "end" },
]

export default function CommandCenterPage() {
  const [isSessionActive, setIsSessionActive] = useState(false)

  return (
    <div className="p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
          Live Command Center
        </h1>
        <p className="text-[#8888aa]">
          Real-time AI session control and monitoring
        </p>
      </motion.div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Processing Latency"
          value="12ms"
          icon={Zap}
          trend="down"
          trendValue="3ms faster"
          delay={0.1}
        />
        <StatCard
          label="Token Efficiency"
          value="99.2%"
          icon={TrendingUp}
          trend="up"
          trendValue="+0.8%"
          delay={0.2}
        />
        <StatCard
          label="SSL Status"
          value="Active"
          icon={Shield}
          trend="neutral"
          trendValue="256-bit"
          delay={0.3}
        />
        <StatCard
          label="Sessions Today"
          value="24"
          icon={Activity}
          trend="up"
          trendValue="+12"
          delay={0.4}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* AI Session Panel - Takes 2 columns */}
        <div className="col-span-2 space-y-6">
          {/* Session Control */}
          <GlassCard className="p-6" delay={0.2}>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-semibold text-[#e0e0ff] mb-1">
                  Neural Session
                </h2>
                <p className="text-sm text-[#8888aa]">
                  {isSessionActive
                    ? "Session active - Processing audio stream"
                    : "Ready to initialize new session"}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div
                  className={`w-3 h-3 rounded-full ${
                    isSessionActive
                      ? "bg-[#00ff88] animate-pulse"
                      : "bg-[#555566]"
                  }`}
                />
                <span
                  className={`text-sm ${
                    isSessionActive ? "text-[#00ff88]" : "text-[#8888aa]"
                  }`}
                >
                  {isSessionActive ? "LIVE" : "STANDBY"}
                </span>
              </div>
            </div>

            {/* Waveform Visualizer */}
            <div className="mb-6 p-4 rounded-xl bg-[rgba(0,0,0,0.3)] border border-[rgba(0,217,255,0.1)]">
              <AudioWaveform isActive={isSessionActive} />
            </div>

            {/* Session Controls */}
            <div className="flex items-center justify-center gap-4">
              <GlowButton
                variant="ghost"
                size="lg"
                className="w-14 h-14 rounded-full p-0"
              >
                <Mic className="w-6 h-6" />
              </GlowButton>

              <GlowButton
                variant={isSessionActive ? "secondary" : "primary"}
                size="lg"
                className="px-12"
                onClick={() => setIsSessionActive(!isSessionActive)}
              >
                {isSessionActive ? (
                  <>
                    <Pause className="w-5 h-5" />
                    <span>End Session</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5" />
                    <span>Start Session</span>
                  </>
                )}
              </GlowButton>

              <GlowButton
                variant="ghost"
                size="lg"
                className="w-14 h-14 rounded-full p-0"
              >
                <BarChart3 className="w-6 h-6" />
              </GlowButton>
            </div>
          </GlassCard>

          {/* Recent Conversations */}
          <GlassCard className="p-6" delay={0.3}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Recent Sessions
              </h2>
              <a
                href="/dashboard/repository"
                className="text-sm text-[#00D9FF] hover:underline"
              >
                View All
              </a>
            </div>

            <div className="space-y-3">
              {recentConversations.map((conv, index) => (
                <motion.div
                  key={conv.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  whileHover={{ x: 5 }}
                  className="p-4 rounded-xl bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.05)] hover:border-[rgba(0,217,255,0.2)] transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-[#e0e0ff] mb-1">
                        {conv.title}
                      </h3>
                      <div className="flex items-center gap-4 text-xs text-[#8888aa]">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {conv.participants}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {conv.duration}
                        </span>
                        <span>{conv.time}</span>
                      </div>
                    </div>
                    <div
                      className={`px-2 py-1 rounded text-xs ${
                        conv.sentiment === "positive"
                          ? "bg-[rgba(0,255,136,0.15)] text-[#00ff88]"
                          : "bg-[rgba(255,255,255,0.1)] text-[#8888aa]"
                      }`}
                    >
                      {conv.sentiment}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Right Column - Activity & Metrics */}
        <div className="space-y-6">
          {/* Live Metrics */}
          <GlassCard className="p-6" glow="purple" delay={0.25}>
            <h2 className="text-lg font-semibold text-[#e0e0ff] mb-4">
              Live Metrics
            </h2>

            <div className="space-y-4">
              {/* Processing Power */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#8888aa]">Neural Processing</span>
                  <span className="text-[#00D9FF]">87%</span>
                </div>
                <div className="h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "87%" }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#00D9FF] to-[#7A5FFF]"
                  />
                </div>
              </div>

              {/* Memory Usage */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#8888aa]">Memory Allocation</span>
                  <span className="text-[#7A5FFF]">62%</span>
                </div>
                <div className="h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "62%" }}
                    transition={{ duration: 1, delay: 0.6 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#7A5FFF] to-[#00D9FF]"
                  />
                </div>
              </div>

              {/* Token Usage */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-[#8888aa]">Token Usage</span>
                  <span className="text-[#00ff88]">45%</span>
                </div>
                <div className="h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: "45%" }}
                    transition={{ duration: 1, delay: 0.7 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#00ff88] to-[#00D9FF]"
                  />
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Activity Timeline */}
          <GlassCard className="p-6" delay={0.35}>
            <h2 className="text-lg font-semibold text-[#e0e0ff] mb-4">
              Activity Timeline
            </h2>

            <div className="space-y-3">
              {activityTimeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        item.type === "start"
                          ? "bg-[#00D9FF]"
                          : item.type === "complete"
                          ? "bg-[#00ff88]"
                          : item.type === "process"
                          ? "bg-[#7A5FFF]"
                          : "bg-[#8888aa]"
                      }`}
                    />
                    {index < activityTimeline.length - 1 && (
                      <div className="w-px h-6 bg-[rgba(255,255,255,0.1)]" />
                    )}
                  </div>
                  <div className="flex-1 -mt-0.5">
                    <p className="text-sm text-[#e0e0ff]">{item.event}</p>
                    <p className="text-xs text-[#555566]">{item.time}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Quick Actions */}
          <GlassCard className="p-6" delay={0.45}>
            <h2 className="text-lg font-semibold text-[#e0e0ff] mb-4">
              Quick Actions
            </h2>

            <div className="grid grid-cols-2 gap-3">
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <MessageSquare className="w-5 h-5 mb-1" />
                <span className="text-xs">New Chat</span>
              </GlowButton>
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <Mic className="w-5 h-5 mb-1" />
                <span className="text-xs">Voice Note</span>
              </GlowButton>
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <BarChart3 className="w-5 h-5 mb-1" />
                <span className="text-xs">Analytics</span>
              </GlowButton>
              <GlowButton variant="ghost" size="sm" className="flex-col py-4 h-auto">
                <Users className="w-5 h-5 mb-1" />
                <span className="text-xs">Team</span>
              </GlowButton>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}
