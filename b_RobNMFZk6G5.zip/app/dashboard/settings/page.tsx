"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Brain,
  Shield,
  Mic,
  Volume2,
  Zap,
  Key,
  Fingerprint,
  Globe,
  Bell,
  Palette,
  Code,
  RefreshCw,
  Check,
  ExternalLink,
  Sparkles,
  Cpu,
  Bot,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"

const aiModels = [
  { id: "neural-4", name: "Neural-4 Ultra", description: "Latest flagship model", recommended: true },
  { id: "neural-3", name: "Neural-3 Pro", description: "Balanced performance" },
  { id: "neural-2", name: "Neural-2 Fast", description: "Optimized for speed" },
  { id: "quantum", name: "Quantum Core", description: "Experimental quantum integration" },
]

const integrations = [
  { name: "Slack", connected: true, icon: "💬" },
  { name: "GitHub", connected: true, icon: "🔗" },
  { name: "Notion", connected: false, icon: "📝" },
  { name: "Linear", connected: false, icon: "📋" },
  { name: "Jira", connected: true, icon: "🎯" },
  { name: "Custom API", connected: false, icon: "🔌" },
]

const voiceOptions = [
  { id: "aria", name: "Aria", accent: "Neutral" },
  { id: "marcus", name: "Marcus", accent: "Professional" },
  { id: "nova", name: "Nova", accent: "Friendly" },
  { id: "alex", name: "Alex", accent: "Technical" },
]

export default function SettingsPage() {
  const [selectedModel, setSelectedModel] = useState("neural-4")
  const [selectedVoice, setSelectedVoice] = useState("aria")
  const [settings, setSettings] = useState({
    autoTranscribe: true,
    smartSummary: true,
    sentimentAnalysis: true,
    entityDetection: true,
    biometricAuth: true,
    quantumEncryption: true,
    voiceSynthesis: false,
    notifications: true,
    darkMode: true,
    betaFeatures: false,
  })

  const [encryptionLevel, setEncryptionLevel] = useState(256)
  const [processingSpeed, setProcessingSpeed] = useState(75)
  const [keyRotationStatus] = useState("Active")

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const ToggleSwitch = ({
    enabled,
    onToggle,
  }: {
    enabled: boolean
    onToggle: () => void
  }) => (
    <button
      onClick={onToggle}
      className={`relative w-12 h-6 rounded-full transition-all duration-300 ${
        enabled
          ? "bg-gradient-to-r from-[#00D9FF] to-[#7A5FFF] shadow-[0_0_15px_rgba(0,217,255,0.4)]"
          : "bg-[rgba(255,255,255,0.1)]"
      }`}
    >
      <motion.div
        animate={{ x: enabled ? 24 : 2 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        className="absolute top-1 w-4 h-4 rounded-full bg-white shadow-lg"
      />
    </button>
  )

  return (
    <div className="p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
          Configuration Console
        </h1>
        <p className="text-[#8888aa]">
          Neural engine settings and system configuration
        </p>
      </motion.div>

      <div className="grid grid-cols-3 gap-6">
        {/* Left Column - AI Engine & Voice */}
        <div className="col-span-2 space-y-6">
          {/* AI Model Selection */}
          <GlassCard className="p-6" delay={0.1}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.15)]">
                <Brain className="w-5 h-5 text-[#00D9FF]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Neural Engine
                </h2>
                <p className="text-sm text-[#8888aa]">
                  Select your AI processing model
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {aiModels.map((model, index) => (
                <motion.button
                  key={model.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.05 }}
                  onClick={() => setSelectedModel(model.id)}
                  className={`relative p-4 rounded-xl text-left transition-all duration-300 ${
                    selectedModel === model.id
                      ? "bg-[rgba(0,217,255,0.15)] border-2 border-[#00D9FF] shadow-[0_0_20px_rgba(0,217,255,0.3)]"
                      : "bg-[rgba(255,255,255,0.03)] border-2 border-transparent hover:border-[rgba(0,217,255,0.3)]"
                  }`}
                >
                  {model.recommended && (
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] bg-[rgba(0,255,136,0.2)] text-[#00ff88]">
                      Recommended
                    </span>
                  )}
                  <div className="flex items-center gap-3 mb-2">
                    <Cpu className={`w-5 h-5 ${selectedModel === model.id ? "text-[#00D9FF]" : "text-[#8888aa]"}`} />
                    <span className={`font-medium ${selectedModel === model.id ? "text-[#00D9FF]" : "text-[#e0e0ff]"}`}>
                      {model.name}
                    </span>
                  </div>
                  <p className="text-xs text-[#8888aa]">{model.description}</p>
                  {selectedModel === model.id && (
                    <motion.div
                      layoutId="modelCheck"
                      className="absolute top-4 right-4 w-5 h-5 rounded-full bg-[#00D9FF] flex items-center justify-center"
                    >
                      <Check className="w-3 h-3 text-[#050816]" />
                    </motion.div>
                  )}
                </motion.button>
              ))}
            </div>

            {/* Processing Speed Slider */}
            <div className="mt-6 pt-6 border-t border-[rgba(255,255,255,0.1)]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-[#8888aa]">Processing Priority</span>
                <span className="text-sm text-[#00D9FF]">{processingSpeed}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={processingSpeed}
                onChange={(e) => setProcessingSpeed(Number(e.target.value))}
                className="w-full h-2 rounded-full appearance-none bg-[rgba(255,255,255,0.1)] cursor-pointer accent-[#00D9FF]"
                style={{
                  background: `linear-gradient(to right, #00D9FF ${processingSpeed}%, rgba(255,255,255,0.1) ${processingSpeed}%)`,
                }}
              />
              <div className="flex justify-between text-xs text-[#555566] mt-1">
                <span>Efficiency</span>
                <span>Performance</span>
              </div>
            </div>
          </GlassCard>

          {/* Voice Synthesis */}
          <GlassCard className="p-6" delay={0.2}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-[rgba(122,95,255,0.15)]">
                  <Volume2 className="w-5 h-5 text-[#7A5FFF]" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#e0e0ff]">
                    Voice Synthesis
                  </h2>
                  <p className="text-sm text-[#8888aa]">
                    AI voice output configuration
                  </p>
                </div>
              </div>
              <ToggleSwitch
                enabled={settings.voiceSynthesis}
                onToggle={() => toggleSetting("voiceSynthesis")}
              />
            </div>

            <div className={`grid grid-cols-4 gap-3 ${!settings.voiceSynthesis && "opacity-50 pointer-events-none"}`}>
              {voiceOptions.map((voice) => (
                <button
                  key={voice.id}
                  onClick={() => setSelectedVoice(voice.id)}
                  className={`p-4 rounded-xl text-center transition-all duration-300 ${
                    selectedVoice === voice.id
                      ? "bg-[rgba(122,95,255,0.2)] border border-[#7A5FFF] shadow-[0_0_15px_rgba(122,95,255,0.3)]"
                      : "bg-[rgba(255,255,255,0.03)] border border-transparent hover:border-[rgba(122,95,255,0.3)]"
                  }`}
                >
                  <Mic className={`w-6 h-6 mx-auto mb-2 ${selectedVoice === voice.id ? "text-[#7A5FFF]" : "text-[#8888aa]"}`} />
                  <p className={`text-sm font-medium ${selectedVoice === voice.id ? "text-[#7A5FFF]" : "text-[#e0e0ff]"}`}>
                    {voice.name}
                  </p>
                  <p className="text-xs text-[#555566]">{voice.accent}</p>
                </button>
              ))}
            </div>
          </GlassCard>

          {/* Feature Toggles */}
          <GlassCard className="p-6" delay={0.3}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[rgba(0,255,136,0.15)]">
                <Sparkles className="w-5 h-5 text-[#00ff88]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  AI Features
                </h2>
                <p className="text-sm text-[#8888aa]">
                  Enable or disable intelligent features
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { key: "autoTranscribe", label: "Auto Transcription", description: "Automatically transcribe all sessions", icon: Mic },
                { key: "smartSummary", label: "Smart Summary", description: "Generate AI summaries after sessions", icon: Brain },
                { key: "sentimentAnalysis", label: "Sentiment Analysis", description: "Analyze emotional tone in conversations", icon: Bot },
                { key: "entityDetection", label: "Entity Detection", description: "Identify people, places, and topics", icon: Zap },
              ].map((feature, index) => (
                <motion.div
                  key={feature.key}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.05 }}
                  className="flex items-center justify-between p-4 rounded-xl bg-[rgba(255,255,255,0.02)]"
                >
                  <div className="flex items-center gap-3">
                    <feature.icon className="w-5 h-5 text-[#8888aa]" />
                    <div>
                      <p className="text-sm font-medium text-[#e0e0ff]">{feature.label}</p>
                      <p className="text-xs text-[#555566]">{feature.description}</p>
                    </div>
                  </div>
                  <ToggleSwitch
                    enabled={settings[feature.key as keyof typeof settings] as boolean}
                    onToggle={() => toggleSetting(feature.key as keyof typeof settings)}
                  />
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Integrations */}
          <GlassCard className="p-6" delay={0.4}>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.15)]">
                  <Globe className="w-5 h-5 text-[#00D9FF]" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#e0e0ff]">
                    Integrations
                  </h2>
                  <p className="text-sm text-[#8888aa]">
                    Connect external services
                  </p>
                </div>
              </div>
              <GlowButton variant="ghost" size="sm">
                <Code className="w-4 h-4" />
                <span>API Docs</span>
              </GlowButton>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {integrations.map((integration, index) => (
                <motion.div
                  key={integration.name}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    integration.connected
                      ? "bg-[rgba(0,255,136,0.08)] border border-[rgba(0,255,136,0.2)]"
                      : "bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.08)]"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl">{integration.icon}</span>
                    {integration.connected ? (
                      <span className="flex items-center gap-1 text-xs text-[#00ff88]">
                        <Check className="w-3 h-3" />
                        Connected
                      </span>
                    ) : (
                      <button className="text-xs text-[#00D9FF] hover:underline flex items-center gap-1">
                        Connect
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                  <p className="text-sm font-medium text-[#e0e0ff]">{integration.name}</p>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </div>

        {/* Right Column - Security */}
        <div className="space-y-6">
          {/* Security Settings */}
          <GlassCard className="p-6" glow="purple" delay={0.15}>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-[rgba(122,95,255,0.15)]">
                <Shield className="w-5 h-5 text-[#7A5FFF]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Security
                </h2>
                <p className="text-sm text-[#8888aa]">
                  Enterprise security settings
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Biometric */}
              <div className="flex items-center justify-between p-3 rounded-lg bg-[rgba(255,255,255,0.03)]">
                <div className="flex items-center gap-3">
                  <Fingerprint className="w-5 h-5 text-[#7A5FFF]" />
                  <div>
                    <p className="text-sm font-medium text-[#e0e0ff]">Biometric Auth</p>
                    <p className="text-xs text-[#555566]">Fingerprint & Face ID</p>
                  </div>
                </div>
                <ToggleSwitch
                  enabled={settings.biometricAuth}
                  onToggle={() => toggleSetting("biometricAuth")}
                />
              </div>

              {/* Quantum Encryption */}
              <div className="flex items-center justify-between p-3 rounded-lg bg-[rgba(255,255,255,0.03)]">
                <div className="flex items-center gap-3">
                  <Key className="w-5 h-5 text-[#00D9FF]" />
                  <div>
                    <p className="text-sm font-medium text-[#e0e0ff]">Quantum Encryption</p>
                    <p className="text-xs text-[#555566]">Next-gen security</p>
                  </div>
                </div>
                <ToggleSwitch
                  enabled={settings.quantumEncryption}
                  onToggle={() => toggleSetting("quantumEncryption")}
                />
              </div>
            </div>

            {/* Encryption Level */}
            <div className="mt-6 pt-4 border-t border-[rgba(255,255,255,0.1)]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-[#8888aa]">Encryption Level</span>
                <span className="text-sm text-[#7A5FFF]">{encryptionLevel}-bit</span>
              </div>
              <div className="flex gap-2">
                {[128, 192, 256, 512].map((level) => (
                  <button
                    key={level}
                    onClick={() => setEncryptionLevel(level)}
                    className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                      encryptionLevel === level
                        ? "bg-[rgba(122,95,255,0.3)] text-[#7A5FFF] shadow-[0_0_10px_rgba(122,95,255,0.3)]"
                        : "bg-[rgba(255,255,255,0.05)] text-[#8888aa] hover:bg-[rgba(255,255,255,0.1)]"
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Key Rotation Status */}
            <div className="mt-4 p-3 rounded-lg bg-[rgba(0,255,136,0.1)] border border-[rgba(0,255,136,0.2)]">
              <div className="flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-[#00ff88]" />
                <span className="text-sm text-[#00ff88]">Quantum Key Rotation: {keyRotationStatus}</span>
              </div>
              <p className="text-xs text-[#8888aa] mt-1">Last rotation: 4 hours ago</p>
            </div>
          </GlassCard>

          {/* Notifications */}
          <GlassCard className="p-6" delay={0.25}>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-[rgba(255,170,0,0.15)]">
                <Bell className="w-5 h-5 text-[#ffaa00]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Notifications
                </h2>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-sm text-[#8888aa]">Enable notifications</p>
              <ToggleSwitch
                enabled={settings.notifications}
                onToggle={() => toggleSetting("notifications")}
              />
            </div>
          </GlassCard>

          {/* Appearance */}
          <GlassCard className="p-6" delay={0.35}>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-[rgba(0,217,255,0.15)]">
                <Palette className="w-5 h-5 text-[#00D9FF]" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-[#e0e0ff]">
                  Appearance
                </h2>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm text-[#8888aa]">Dark Mode</p>
                <ToggleSwitch
                  enabled={settings.darkMode}
                  onToggle={() => toggleSetting("darkMode")}
                />
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm text-[#8888aa]">Beta Features</p>
                <ToggleSwitch
                  enabled={settings.betaFeatures}
                  onToggle={() => toggleSetting("betaFeatures")}
                />
              </div>
            </div>
          </GlassCard>

          {/* Save Button */}
          <GlowButton className="w-full" size="lg">
            <Check className="w-5 h-5" />
            <span>Save Configuration</span>
          </GlowButton>
        </div>
      </div>
    </div>
  )
}
