"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Search,
  Filter,
  Calendar,
  Users,
  Tag,
  Clock,
  TrendingUp,
  ChevronDown,
  Play,
  Download,
  Trash2,
  MoreHorizontal,
  Database,
  HardDrive,
  Hash,
  FileText,
  ArrowUpRight,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"
import { StatCard } from "@/components/stat-card"

const meetings = [
  {
    id: 1,
    title: "Q4 Strategy Planning Session",
    date: "2024-01-15",
    duration: "1:23:45",
    participants: ["Sarah Chen", "Marcus Johnson", "Elena Rodriguez", "David Kim"],
    sentiment: 85,
    keywords: ["roadmap", "Q4", "enterprise", "SSO", "analytics"],
    project: "Enterprise Suite",
  },
  {
    id: 2,
    title: "Product Roadmap Review",
    date: "2024-01-14",
    duration: "45:30",
    participants: ["Elena Rodriguez", "Alex Thompson"],
    sentiment: 72,
    keywords: ["features", "timeline", "MVP", "beta"],
    project: "Mobile App",
  },
  {
    id: 3,
    title: "Client Onboarding - Acme Corp",
    date: "2024-01-13",
    duration: "32:15",
    participants: ["Sarah Chen", "Client Team"],
    sentiment: 92,
    keywords: ["onboarding", "integration", "success"],
    project: "Client Success",
  },
  {
    id: 4,
    title: "Engineering Sprint Planning",
    date: "2024-01-12",
    duration: "1:05:20",
    participants: ["Marcus Johnson", "Dev Team"],
    sentiment: 78,
    keywords: ["sprint", "tickets", "velocity", "blockers"],
    project: "Engineering",
  },
  {
    id: 5,
    title: "Marketing Campaign Review",
    date: "2024-01-11",
    duration: "52:40",
    participants: ["Marketing Team", "Elena Rodriguez"],
    sentiment: 68,
    keywords: ["campaign", "ROI", "conversion", "leads"],
    project: "Marketing",
  },
  {
    id: 6,
    title: "Security Audit Discussion",
    date: "2024-01-10",
    duration: "1:15:00",
    participants: ["Marcus Johnson", "Security Team"],
    sentiment: 75,
    keywords: ["security", "audit", "compliance", "SOC2"],
    project: "Infrastructure",
  },
]

const projects = ["All Projects", "Enterprise Suite", "Mobile App", "Client Success", "Engineering", "Marketing", "Infrastructure"]

export default function RepositoryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProject, setSelectedProject] = useState("All Projects")
  const [expandedMeeting, setExpandedMeeting] = useState<number | null>(null)

  const filteredMeetings = meetings.filter((meeting) => {
    const matchesSearch =
      meeting.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      meeting.keywords.some((k) => k.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesProject = selectedProject === "All Projects" || meeting.project === selectedProject
    return matchesSearch && matchesProject
  })

  const getSentimentColor = (score: number) => {
    if (score >= 80) return "#00ff88"
    if (score >= 60) return "#00D9FF"
    if (score >= 40) return "#ffaa00"
    return "#ff4466"
  }

  return (
    <div className="p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
          Cognitive Repository
        </h1>
        <p className="text-[#8888aa]">
          Archive and search all AI-processed intelligence sessions
        </p>
      </motion.div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Sessions Processed"
          value="128"
          icon={FileText}
          trend="up"
          trendValue="+24 this week"
          delay={0.1}
        />
        <StatCard
          label="Data Analyzed"
          value="12.4 GB"
          icon={HardDrive}
          trend="up"
          trendValue="+2.1 GB"
          delay={0.2}
        />
        <StatCard
          label="Keywords Identified"
          value="2,482"
          icon={Hash}
          trend="up"
          trendValue="+156"
          delay={0.3}
        />
        <StatCard
          label="Avg Sentiment"
          value="76%"
          icon={TrendingUp}
          trend="up"
          trendValue="+4%"
          delay={0.4}
        />
      </div>

      {/* Search and Filters */}
      <GlassCard className="p-6 mb-6" hover={false} delay={0.2}>
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8888aa]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search sessions, keywords, or participants..."
              className="w-full pl-11 pr-4 py-3 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] placeholder:text-[#555566] focus:outline-none focus:border-[#00D9FF] focus:shadow-[0_0_20px_rgba(0,217,255,0.2)] transition-all"
            />
          </div>

          {/* Filters */}
          <div className="flex gap-3">
            {/* Project Filter */}
            <div className="relative">
              <select
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
                className="appearance-none px-4 py-3 pr-10 rounded-lg bg-[rgba(255,255,255,0.06)] border border-[rgba(0,217,255,0.15)] text-[#e0e0ff] focus:outline-none focus:border-[#00D9FF] cursor-pointer"
              >
                {projects.map((project) => (
                  <option key={project} value={project} className="bg-[#0a0f23]">
                    {project}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8888aa] pointer-events-none" />
            </div>

            <GlowButton variant="ghost" className="gap-2">
              <Calendar className="w-4 h-4" />
              <span>Date</span>
            </GlowButton>

            <GlowButton variant="ghost" className="gap-2">
              <Users className="w-4 h-4" />
              <span>Participants</span>
            </GlowButton>

            <GlowButton variant="ghost" className="gap-2">
              <Filter className="w-4 h-4" />
              <span>More Filters</span>
            </GlowButton>
          </div>
        </div>
      </GlassCard>

      {/* Results count */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-[#8888aa]">
          Showing {filteredMeetings.length} of {meetings.length} sessions
        </p>
        <div className="flex items-center gap-2 text-sm text-[#8888aa]">
          <Database className="w-4 h-4" />
          <span>Last synced: 2 minutes ago</span>
        </div>
      </div>

      {/* Meeting Cards */}
      <div className="space-y-4">
        {filteredMeetings.map((meeting, index) => (
          <motion.div
            key={meeting.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + index * 0.05 }}
          >
            <GlassCard
              className="p-6 cursor-pointer"
              hover
              onClick={() => setExpandedMeeting(expandedMeeting === meeting.id ? null : meeting.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-[#e0e0ff]">
                      {meeting.title}
                    </h3>
                    <span className="px-2 py-0.5 rounded text-xs bg-[rgba(122,95,255,0.15)] text-[#7A5FFF]">
                      {meeting.project}
                    </span>
                  </div>

                  <div className="flex items-center gap-6 text-sm text-[#8888aa] mb-4">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      {new Date(meeting.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {meeting.duration}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Users className="w-4 h-4" />
                      {meeting.participants.length} participants
                    </span>
                  </div>

                  {/* Keywords */}
                  <div className="flex flex-wrap gap-2">
                    {meeting.keywords.map((keyword) => (
                      <span
                        key={keyword}
                        className="px-2 py-1 rounded text-xs bg-[rgba(0,217,255,0.1)] text-[#00D9FF] flex items-center gap-1"
                      >
                        <Tag className="w-3 h-3" />
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Sentiment & Actions */}
                <div className="flex items-start gap-6">
                  {/* Sentiment Score */}
                  <div className="text-center">
                    <div className="relative w-16 h-16">
                      <svg className="w-full h-full -rotate-90">
                        <circle
                          cx="32"
                          cy="32"
                          r="28"
                          fill="none"
                          stroke="rgba(255,255,255,0.1)"
                          strokeWidth="4"
                        />
                        <motion.circle
                          cx="32"
                          cy="32"
                          r="28"
                          fill="none"
                          stroke={getSentimentColor(meeting.sentiment)}
                          strokeWidth="4"
                          strokeLinecap="round"
                          strokeDasharray={176}
                          initial={{ strokeDashoffset: 176 }}
                          animate={{ strokeDashoffset: 176 - (176 * meeting.sentiment) / 100 }}
                          transition={{ duration: 1, delay: 0.3 + index * 0.1 }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span
                          className="text-lg font-bold"
                          style={{ color: getSentimentColor(meeting.sentiment) }}
                        >
                          {meeting.sentiment}
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-[#8888aa] mt-1">Sentiment</p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <GlowButton variant="ghost" size="sm" className="w-10 h-10 p-0">
                      <Play className="w-4 h-4" />
                    </GlowButton>
                    <GlowButton variant="ghost" size="sm" className="w-10 h-10 p-0">
                      <Download className="w-4 h-4" />
                    </GlowButton>
                    <GlowButton variant="ghost" size="sm" className="w-10 h-10 p-0">
                      <MoreHorizontal className="w-4 h-4" />
                    </GlowButton>
                  </div>
                </div>
              </div>

              {/* Expanded Content */}
              <AnimatePresence>
                {expandedMeeting === meeting.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-6 pt-6 border-t border-[rgba(255,255,255,0.1)]"
                  >
                    <div className="grid grid-cols-3 gap-6">
                      {/* Participants */}
                      <div>
                        <h4 className="text-sm font-medium text-[#8888aa] mb-3">
                          Participants
                        </h4>
                        <div className="space-y-2">
                          {meeting.participants.map((participant, i) => (
                            <div
                              key={i}
                              className="flex items-center gap-2 text-sm text-[#e0e0ff]"
                            >
                              <div className="w-6 h-6 rounded-full bg-[rgba(0,217,255,0.2)] flex items-center justify-center text-xs text-[#00D9FF]">
                                {participant[0]}
                              </div>
                              {participant}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Quick Actions */}
                      <div>
                        <h4 className="text-sm font-medium text-[#8888aa] mb-3">
                          Quick Actions
                        </h4>
                        <div className="space-y-2">
                          <button className="w-full text-left px-3 py-2 rounded-lg text-sm text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)] transition-colors flex items-center gap-2">
                            <FileText className="w-4 h-4 text-[#00D9FF]" />
                            View Full Transcript
                          </button>
                          <button className="w-full text-left px-3 py-2 rounded-lg text-sm text-[#e0e0ff] hover:bg-[rgba(255,255,255,0.05)] transition-colors flex items-center gap-2">
                            <ArrowUpRight className="w-4 h-4 text-[#7A5FFF]" />
                            Export Summary
                          </button>
                          <button className="w-full text-left px-3 py-2 rounded-lg text-sm text-[#ff4466] hover:bg-[rgba(255,68,102,0.1)] transition-colors flex items-center gap-2">
                            <Trash2 className="w-4 h-4" />
                            Delete Session
                          </button>
                        </div>
                      </div>

                      {/* AI Insights */}
                      <div>
                        <h4 className="text-sm font-medium text-[#8888aa] mb-3">
                          AI Insights
                        </h4>
                        <p className="text-sm text-[#e0e0ff] leading-relaxed">
                          This session demonstrated strong team alignment on Q4 priorities.
                          Key decisions included SSO integration timeline and resource allocation
                          for the analytics dashboard.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Load More */}
      {filteredMeetings.length > 0 && (
        <div className="mt-8 text-center">
          <GlowButton variant="ghost">Load More Sessions</GlowButton>
        </div>
      )}
    </div>
  )
}
