"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Mic,
  MicOff,
  Download,
  Share2,
  CheckSquare,
  Target,
  Heart,
  Building2,
  User,
  Clock,
  TrendingUp,
  Sparkles,
} from "lucide-react"
import { GlassCard } from "@/components/glass-card"
import { GlowButton } from "@/components/glow-button"

const speakers = [
  { id: "sarah", name: "Sarah Chen", role: "CEO", color: "#00D9FF" },
  { id: "marcus", name: "Marcus Johnson", role: "CTO", color: "#7A5FFF" },
  { id: "elena", name: "Elena Rodriguez", role: "Product", color: "#00ff88" },
]

const initialTranscript = [
  {
    id: 1,
    speaker: "sarah",
    text: "Let's discuss our Q4 roadmap priorities. I believe we should focus on the enterprise features our clients have been requesting.",
    timestamp: "00:00:12",
    sentiment: "positive",
  },
  {
    id: 2,
    speaker: "marcus",
    text: "Agreed. The technical infrastructure is ready to support the new authentication system. We can have the SSO integration completed within three weeks.",
    timestamp: "00:00:34",
    sentiment: "positive",
  },
  {
    id: 3,
    speaker: "elena",
    text: "From a product perspective, I think we should also prioritize the analytics dashboard. User feedback has been overwhelmingly positive about the beta version.",
    timestamp: "00:01:02",
    sentiment: "positive",
  },
  {
    id: 4,
    speaker: "sarah",
    text: "Excellent points. Marcus, what resources would you need to accelerate the SSO timeline?",
    timestamp: "00:01:28",
    sentiment: "neutral",
  },
  {
    id: 5,
    speaker: "marcus",
    text: "Two additional senior engineers and access to the Azure AD sandbox environment. I can have a detailed proposal by end of day.",
    timestamp: "00:01:45",
    sentiment: "neutral",
  },
]

const aiSummary = {
  keyObjectives: [
    "Complete SSO integration within 3 weeks",
    "Prioritize enterprise authentication features",
    "Launch analytics dashboard based on beta feedback",
    "Allocate additional engineering resources",
  ],
  actionItems: [
    { task: "Prepare SSO resource proposal", assignee: "Marcus Johnson", due: "Today EOD" },
    { task: "Schedule Azure AD sandbox access", assignee: "IT Team", due: "Tomorrow" },
    { task: "Share beta analytics feedback report", assignee: "Elena Rodriguez", due: "This week" },
    { task: "Review Q4 budget for new hires", assignee: "Sarah Chen", due: "Friday" },
  ],
  entities: [
    { type: "Organization", value: "Azure AD" },
    { type: "Feature", value: "SSO Integration" },
    { type: "Feature", value: "Analytics Dashboard" },
    { type: "Timeline", value: "Q4 Roadmap" },
  ],
  sentimentAnalysis: {
    overall: "Positive",
    score: 78,
    breakdown: { positive: 65, neutral: 30, negative: 5 },
  },
}

export default function TranscriptPage() {
  const [isRecording, setIsRecording] = useState(false)
  const [transcript, setTranscript] = useState(initialTranscript)
  const [typingIndex, setTypingIndex] = useState<number | null>(null)

  // Simulate live transcription
  useEffect(() => {
    if (!isRecording) return

    const newMessages = [
      {
        id: transcript.length + 1,
        speaker: "elena",
        text: "I can also provide user research data to support the SSO prioritization decision.",
        timestamp: "00:02:15",
        sentiment: "positive",
      },
      {
        id: transcript.length + 2,
        speaker: "sarah",
        text: "Perfect. Let's reconvene Thursday with all proposals on the table.",
        timestamp: "00:02:38",
        sentiment: "positive",
      },
    ]

    const timeouts: NodeJS.Timeout[] = []
    
    newMessages.forEach((msg, index) => {
      const timeout = setTimeout(() => {
        setTypingIndex(msg.id)
        setTimeout(() => {
          setTranscript((prev) => [...prev, msg])
          setTypingIndex(null)
        }, 1500)
      }, (index + 1) * 3000)
      timeouts.push(timeout)
    })

    return () => timeouts.forEach(clearTimeout)
  }, [isRecording, transcript.length])

  const getSpeaker = (id: string) => speakers.find((s) => s.id === id) || speakers[0]

  return (
    <div className="p-8 h-[calc(100vh-2rem)]">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between mb-6"
      >
        <div>
          <h1 className="text-3xl font-bold text-[#e0e0ff] mb-2">
            Live Transcript & Summary
          </h1>
          <p className="text-[#8888aa]">
            AI-powered meeting intelligence with real-time analysis
          </p>
        </div>
        <div className="flex items-center gap-3">
          <GlowButton
            variant={isRecording ? "secondary" : "primary"}
            onClick={() => setIsRecording(!isRecording)}
          >
            {isRecording ? (
              <>
                <MicOff className="w-5 h-5" />
                <span>Stop Recording</span>
              </>
            ) : (
              <>
                <Mic className="w-5 h-5" />
                <span>Start Recording</span>
              </>
            )}
          </GlowButton>
          <GlowButton variant="ghost">
            <Download className="w-5 h-5" />
          </GlowButton>
          <GlowButton variant="ghost">
            <Share2 className="w-5 h-5" />
          </GlowButton>
        </div>
      </motion.div>

      {/* Recording indicator */}
      <AnimatePresence>
        {isRecording && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4"
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[rgba(255,68,102,0.15)] border border-[rgba(255,68,102,0.3)]">
              <div className="w-3 h-3 rounded-full bg-[#ff4466] animate-pulse" />
              <span className="text-sm text-[#ff4466]">Recording in progress</span>
              <span className="text-xs text-[#8888aa] ml-auto">
                <Clock className="w-3 h-3 inline mr-1" />
                02:45
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content - Split View */}
      <div className="grid grid-cols-2 gap-6 h-[calc(100%-8rem)]">
        {/* Left - Live Transcript */}
        <GlassCard className="p-6 flex flex-col h-full overflow-hidden" hover={false}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-[#e0e0ff]">
              Live Transcript
            </h2>
            <span className="text-xs text-[#8888aa]">
              {transcript.length} segments
            </span>
          </div>

          {/* Speakers */}
          <div className="flex gap-2 mb-4 pb-4 border-b border-[rgba(255,255,255,0.1)]">
            {speakers.map((speaker) => (
              <div
                key={speaker.id}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[rgba(255,255,255,0.05)]"
              >
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium"
                  style={{ backgroundColor: `${speaker.color}20`, color: speaker.color }}
                >
                  {speaker.name[0]}
                </div>
                <span className="text-xs text-[#e0e0ff]">{speaker.name}</span>
              </div>
            ))}
          </div>

          {/* Transcript List */}
          <div className="flex-1 overflow-y-auto space-y-4 pr-2">
            {transcript.map((item, index) => {
              const speaker = getSpeaker(item.speaker)
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="group"
                >
                  <div className="flex gap-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0"
                      style={{
                        backgroundColor: `${speaker.color}20`,
                        color: speaker.color,
                      }}
                    >
                      {speaker.name[0]}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium" style={{ color: speaker.color }}>
                          {speaker.name}
                        </span>
                        <span className="text-xs text-[#555566]">
                          {item.timestamp}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded ${
                            item.sentiment === "positive"
                              ? "bg-[rgba(0,255,136,0.15)] text-[#00ff88]"
                              : item.sentiment === "negative"
                              ? "bg-[rgba(255,68,102,0.15)] text-[#ff4466]"
                              : "bg-[rgba(255,255,255,0.1)] text-[#8888aa]"
                          }`}
                        >
                          {item.sentiment}
                        </span>
                      </div>
                      <p className="text-sm text-[#e0e0ff] leading-relaxed">
                        {item.text}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )
            })}

            {/* Typing indicator */}
            <AnimatePresence>
              {typingIndex !== null && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex gap-3"
                >
                  <div className="w-8 h-8 rounded-full bg-[rgba(122,95,255,0.2)] flex items-center justify-center">
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#7A5FFF] animate-bounce" style={{ animationDelay: "0ms" }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-[#7A5FFF] animate-bounce" style={{ animationDelay: "150ms" }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-[#7A5FFF] animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="h-4 w-48 rounded bg-[rgba(255,255,255,0.1)] animate-pulse" />
                    <div className="h-3 w-full mt-2 rounded bg-[rgba(255,255,255,0.05)] animate-pulse" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </GlassCard>

        {/* Right - AI Summary */}
        <div className="space-y-6 h-full overflow-y-auto pr-2">
          {/* Sentiment Analysis */}
          <GlassCard className="p-6" glow="purple" delay={0.1}>
            <div className="flex items-center gap-2 mb-4">
              <Heart className="w-5 h-5 text-[#7A5FFF]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Sentiment Analysis
              </h2>
            </div>

            <div className="flex items-center gap-6 mb-4">
              <div className="text-center">
                <div className="text-4xl font-bold text-[#00ff88]">
                  {aiSummary.sentimentAnalysis.score}%
                </div>
                <div className="text-xs text-[#8888aa]">Overall Score</div>
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888aa] w-16">Positive</span>
                  <div className="flex-1 h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${aiSummary.sentimentAnalysis.breakdown.positive}%` }}
                      transition={{ duration: 1 }}
                      className="h-full bg-[#00ff88] rounded-full"
                    />
                  </div>
                  <span className="text-xs text-[#00ff88] w-8">
                    {aiSummary.sentimentAnalysis.breakdown.positive}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888aa] w-16">Neutral</span>
                  <div className="flex-1 h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${aiSummary.sentimentAnalysis.breakdown.neutral}%` }}
                      transition={{ duration: 1, delay: 0.1 }}
                      className="h-full bg-[#8888aa] rounded-full"
                    />
                  </div>
                  <span className="text-xs text-[#8888aa] w-8">
                    {aiSummary.sentimentAnalysis.breakdown.neutral}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#8888aa] w-16">Negative</span>
                  <div className="flex-1 h-2 rounded-full bg-[rgba(255,255,255,0.1)] overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${aiSummary.sentimentAnalysis.breakdown.negative}%` }}
                      transition={{ duration: 1, delay: 0.2 }}
                      className="h-full bg-[#ff4466] rounded-full"
                    />
                  </div>
                  <span className="text-xs text-[#ff4466] w-8">
                    {aiSummary.sentimentAnalysis.breakdown.negative}%
                  </span>
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Key Objectives */}
          <GlassCard className="p-6" delay={0.2}>
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-[#00D9FF]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Key Objectives
              </h2>
            </div>

            <ul className="space-y-2">
              {aiSummary.keyObjectives.map((objective, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="flex items-start gap-2 text-sm text-[#e0e0ff]"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00D9FF] mt-2 flex-shrink-0" />
                  {objective}
                </motion.li>
              ))}
            </ul>
          </GlassCard>

          {/* Action Items */}
          <GlassCard className="p-6" delay={0.3}>
            <div className="flex items-center gap-2 mb-4">
              <CheckSquare className="w-5 h-5 text-[#00ff88]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Action Items
              </h2>
            </div>

            <div className="space-y-3">
              {aiSummary.actionItems.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="p-3 rounded-lg bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.05)]"
                >
                  <p className="text-sm text-[#e0e0ff] mb-2">{item.task}</p>
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1 text-[#7A5FFF]">
                      <User className="w-3 h-3" />
                      {item.assignee}
                    </span>
                    <span className="text-[#8888aa]">{item.due}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassCard>

          {/* Entity Detection */}
          <GlassCard className="p-6" delay={0.4}>
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-[#7A5FFF]" />
              <h2 className="text-lg font-semibold text-[#e0e0ff]">
                Detected Entities
              </h2>
            </div>

            <div className="flex flex-wrap gap-2">
              {aiSummary.entities.map((entity, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + index * 0.05 }}
                  className={`px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 ${
                    entity.type === "Organization"
                      ? "bg-[rgba(0,217,255,0.15)] text-[#00D9FF]"
                      : entity.type === "Feature"
                      ? "bg-[rgba(122,95,255,0.15)] text-[#7A5FFF]"
                      : "bg-[rgba(0,255,136,0.15)] text-[#00ff88]"
                  }`}
                >
                  {entity.type === "Organization" && <Building2 className="w-3 h-3" />}
                  {entity.type === "Feature" && <Sparkles className="w-3 h-3" />}
                  {entity.type === "Timeline" && <TrendingUp className="w-3 h-3" />}
                  {entity.value}
                </motion.span>
              ))}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}
